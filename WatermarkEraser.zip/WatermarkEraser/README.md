# Watermark Eraser (Android)

Pick a photo, the app finds the watermark (bottom-right first, then other corners), marks it in red,
and rebuilds that area from the surrounding texture. All processing is on the phone: no internet, no permissions.

## How to use
1. **Open** a photo (or Share a photo from your gallery to *Watermark Eraser*).
2. The detected watermark shows in **red** and the view zooms to it.
   - **Brush**: paint over anything the detector missed.
   - **Unmark**: remove red from areas that aren't the watermark.
   - **Move**: pan with one finger. Pinch to zoom anywhere, double-tap to reset.
   - **Clear red**: start the mask from scratch.
3. Tap **Erase**, or with several photos: fix the red area on each one (it's remembered when you switch;
   a violet badge marks photos waiting) and tap **Erase all** to do them all in one go.
   Photos you didn't open get their watermark detected automatically. Not perfect? **Undo**, or brush the leftovers and Erase again.
4. **Save** (goes to `Pictures/WatermarkEraser`) or **Share**.
   After saving, the originals are moved to the Trash (Android asks you to confirm; recoverable for ~30 days).
   Turn this off with ⋮ → *Delete originals after saving*.

Tip: cover the whole watermark *including its shadow/glow* with a little margin. Leftover edges make faint ghosts.

## Getting the APK

### Option A: build in the cloud with GitHub (no software to install)
1. Create a new repository on github.com and upload this whole folder (keep the `.github` folder).
2. Open the **Actions** tab. The *Build APK* workflow runs automatically (about 3–5 min).
3. Open the finished run, download **WatermarkEraser-apk** under *Artifacts*, and unzip it.
4. Copy `app-release.apk` to your phone and open it. Allow "install unknown apps" when asked.

### Option B: Android Studio
Open this folder in Android Studio (Ladybug or newer), let Gradle sync, then hit **Run** with your phone
connected (USB debugging on), or use *Build → Build APK(s)*.

### Option C: command line
Needs JDK 17 and the Android SDK (`ANDROID_HOME` set): `./gradlew assembleRelease`
Output: `app/build/outputs/apk/release/app-release.apk`

Requires Android 10 or newer. Photos larger than 4096 px on the long side are scaled down to 4096 px.

## How it works
- `core/WatermarkDetector.kt`: finds stroke pixels that are clearly brighter (or darker) than their surroundings,
  keeps glyph-shaped blobs, and chains glyphs of similar height on the same baseline into text lines. Lines near
  corners score highest, bottom-right most of all. The winning line is dilated to cover anti-aliasing and shadows.
- `core/Inpainter.kt`: exemplar-based inpainting (Criminisi). The hole is filled patch by patch from the best-matching
  real texture nearby, following edges into the hole first. The search runs on a downscaled region for speed, then
  the source map is applied at full resolution so the fill keeps real detail and grain.
- Neither file depends on Android, so they can be tested on a desktop JVM.

## Limits
- Detection targets **text** watermarks (©, names, URLs). Logos or icons may not be found: just paint them with the Brush.
- Large, tiled or centre watermarks over detailed subjects (faces, writing) are hard for any non-AI method.
  Results there will be visible.
- Only remove watermarks from photos you own or have the rights to edit.
