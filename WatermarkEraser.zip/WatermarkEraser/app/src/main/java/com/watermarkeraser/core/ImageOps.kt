package com.watermarkeraser.core

import kotlin.math.max
import kotlin.math.min

/**
 * Small, Android-independent image helpers.
 * Pixels are packed ARGB ints; masks are ByteArrays holding 0 (keep) or 1 (remove).
 */
internal object ImageOps {

    fun gray(argb: Int): Int {
        val r = (argb shr 16) and 0xff
        val g = (argb shr 8) and 0xff
        val b = argb and 0xff
        return (r * 77 + g * 150 + b * 29) shr 8
    }

    /** Area-averaged downscale to a grayscale float image of size dw x dh. */
    fun downscaleGray(px: IntArray, w: Int, h: Int, dw: Int, dh: Int): FloatArray {
        val out = FloatArray(dw * dh)
        for (y in 0 until dh) {
            val y0 = y * h / dh
            val y1 = max(y0 + 1, (y + 1) * h / dh)
            for (x in 0 until dw) {
                val x0 = x * w / dw
                val x1 = max(x0 + 1, (x + 1) * w / dw)
                var sum = 0
                for (yy in y0 until y1) {
                    val row = yy * w
                    for (xx in x0 until x1) sum += gray(px[row + xx])
                }
                out[y * dw + x] = sum.toFloat() / ((y1 - y0) * (x1 - x0))
            }
        }
        return out
    }

    /** Area-averaged downscale of colourfulness (max channel − min channel). */
    fun downscaleChroma(px: IntArray, w: Int, h: Int, dw: Int, dh: Int): FloatArray {
        val out = FloatArray(dw * dh)
        for (y in 0 until dh) {
            val y0 = y * h / dh
            val y1 = max(y0 + 1, (y + 1) * h / dh)
            for (x in 0 until dw) {
                val x0 = x * w / dw
                val x1 = max(x0 + 1, (x + 1) * w / dw)
                var sum = 0
                for (yy in y0 until y1) {
                    val row = yy * w
                    for (xx in x0 until x1) {
                        val p = px[row + xx]
                        val r = (p shr 16) and 0xff; val g = (p shr 8) and 0xff; val b = p and 0xff
                        sum += max(r, max(g, b)) - min(r, min(g, b))
                    }
                }
                out[y * dw + x] = sum.toFloat() / ((y1 - y0) * (x1 - x0))
            }
        }
        return out
    }

    /** Box blur with radius r using an integral image. */
    fun boxBlur(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val iw = w + 1
        val integral = DoubleArray(iw * (h + 1))
        for (y in 0 until h) {
            var rowSum = 0.0
            for (x in 0 until w) {
                rowSum += src[y * w + x]
                integral[(y + 1) * iw + x + 1] = integral[y * iw + x + 1] + rowSum
            }
        }
        val out = FloatArray(w * h)
        for (y in 0 until h) {
            val y0 = max(0, y - r); val y1 = min(h, y + r + 1)
            for (x in 0 until w) {
                val x0 = max(0, x - r); val x1 = min(w, x + r + 1)
                val s = integral[y1 * iw + x1] - integral[y0 * iw + x1] - integral[y1 * iw + x0] + integral[y0 * iw + x0]
                out[y * w + x] = (s / ((y1 - y0) * (x1 - x0))).toFloat()
            }
        }
        return out
    }

    /** Square dilation of radius r (separable, O(n)). */
    fun dilate(mask: ByteArray, w: Int, h: Int, r: Int): ByteArray {
        if (r <= 0) return mask.copyOf()
        val tmp = ByteArray(w * h)
        for (y in 0 until h) {
            val row = y * w
            var count = 0
            for (x in 0 until min(w, r)) count += mask[row + x]
            for (x in 0 until w) {
                val add = x + r
                if (add < w) count += mask[row + add]
                val rem = x - r - 1
                if (rem >= 0) count -= mask[row + rem]
                if (count > 0) tmp[row + x] = 1
            }
        }
        val out = ByteArray(w * h)
        for (x in 0 until w) {
            var count = 0
            for (y in 0 until min(h, r)) count += tmp[y * w + x]
            for (y in 0 until h) {
                val add = y + r
                if (add < h) count += tmp[add * w + x]
                val rem = y - r - 1
                if (rem >= 0) count -= tmp[rem * w + x]
                if (count > 0) out[y * w + x] = 1
            }
        }
        return out
    }

    /**
     * Fills enclosed holes inside rect [x0,x1) x [y0,y1) in place (e.g. the inside of an "o" or a logo outline).
     * Holes larger than [maxHole] pixels are left alone.
     */
    fun fillHoles(mask: ByteArray, w: Int, x0: Int, y0: Int, x1: Int, y1: Int, maxHole: Int = Int.MAX_VALUE) {
        val rw = x1 - x0; val rh = y1 - y0
        if (rw <= 2 || rh <= 2) return
        val seen = BooleanArray(rw * rh)
        val queue = IntArray(rw * rh)
        var head = 0; var tail = 0
        fun push(x: Int, y: Int) {
            val li = (y - y0) * rw + (x - x0)
            if (!seen[li] && mask[y * w + x].toInt() == 0) { seen[li] = true; queue[tail++] = li }
        }
        for (x in x0 until x1) { push(x, y0); push(x, y1 - 1) }
        for (y in y0 until y1) { push(x0, y); push(x1 - 1, y) }
        while (head < tail) {
            val li = queue[head++]
            val x = li % rw + x0; val y = li / rw + y0
            if (x > x0) push(x - 1, y)
            if (x < x1 - 1) push(x + 1, y)
            if (y > y0) push(x, y - 1)
            if (y < y1 - 1) push(x, y + 1)
        }
        // Remaining zero pixels are holes; fill each one that is small enough.
        for (sy in y0 until y1) for (sx in x0 until x1) {
            val sli = (sy - y0) * rw + (sx - x0)
            if (seen[sli] || mask[sy * w + sx].toInt() != 0) continue
            head = 0; tail = 0
            seen[sli] = true; queue[tail++] = sli
            while (head < tail) {
                val li = queue[head++]
                val x = li % rw + x0; val y = li / rw + y0
                if (x > x0) push(x - 1, y)
                if (x < x1 - 1) push(x + 1, y)
                if (y > y0) push(x, y - 1)
                if (y < y1 - 1) push(x, y + 1)
            }
            if (tail <= maxHole) for (k in 0 until tail) {
                val li = queue[k]
                mask[(li / rw + y0) * w + (li % rw + x0)] = 1
            }
        }
    }

    class Component(val count: Int, val minX: Int, val minY: Int, val maxX: Int, val maxY: Int)

    /** 8-connected components of `bin` restricted to rect [x0,x1) x [y0,y1). */
    fun components(bin: ByteArray, w: Int, x0: Int, y0: Int, x1: Int, y1: Int): List<Component> {
        val rw = x1 - x0; val rh = y1 - y0
        val seen = BooleanArray(rw * rh)
        val queue = IntArray(rw * rh)
        val result = ArrayList<Component>()
        for (sy in y0 until y1) for (sx in x0 until x1) {
            val sli = (sy - y0) * rw + (sx - x0)
            if (seen[sli] || bin[sy * w + sx].toInt() == 0) continue
            var head = 0; var tail = 0
            seen[sli] = true; queue[tail++] = sli
            var count = 0
            var mnx = sx; var mny = sy; var mxx = sx; var mxy = sy
            while (head < tail) {
                val li = queue[head++]
                val x = li % rw + x0; val y = li / rw + y0
                count++
                if (x < mnx) mnx = x; if (x > mxx) mxx = x
                if (y < mny) mny = y; if (y > mxy) mxy = y
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx; val ny = y + dy
                    if (nx < x0 || ny < y0 || nx >= x1 || ny >= y1) continue
                    val nli = (ny - y0) * rw + (nx - x0)
                    if (!seen[nli] && bin[ny * w + nx].toInt() != 0) { seen[nli] = true; queue[tail++] = nli }
                }
            }
            result.add(Component(count, mnx, mny, mxx, mxy))
        }
        return result
    }
}
