package com.watermarkeraser

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/** One photo in the batch. Edited versions live as files in the cache, so only the open photo is in memory. */
class PhotoItem(val uri: Uri) {
    enum class State { NEW, WORKING, CLEANED, NOT_FOUND, SAVED }

    val id = nextId++
    var state = State.NEW
    var thumb: Bitmap? = null
    val versions = ArrayList<File>()   // edited versions, newest last
    var savedUri: Uri? = null

    val isEdited get() = versions.isNotEmpty()

    companion object { private var nextId = 1L }
}

object Photos {
    const val MAX_SIDE = 4096
    private const val THUMB_SIDE = 192
    private const val MAX_VERSIONS = 10

    /** Decodes a photo (content Uri or cache file) as a mutable software ARGB bitmap, at most [maxSide] px. */
    fun decode(context: Context, uri: Uri?, file: File?, maxSide: Int = MAX_SIDE): Bitmap {
        val source = if (file != null) ImageDecoder.createSource(file) else ImageDecoder.createSource(context.contentResolver, uri!!)
        val bmp = ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            decoder.isMutableRequired = true
            val w = info.size.width; val h = info.size.height
            val longest = max(w, h)
            if (longest > maxSide) {
                val f = maxSide.toFloat() / longest
                decoder.setTargetSize(max(1, (w * f).roundToInt()), max(1, (h * f).roundToInt()))
            }
        }
        return if (bmp.config != Bitmap.Config.ARGB_8888) bmp.copy(Bitmap.Config.ARGB_8888, true) else bmp
    }

    /** The current state of a photo: its latest edit, or the original. */
    fun decodeCurrent(context: Context, item: PhotoItem): Bitmap =
        decode(context, item.uri, item.versions.lastOrNull())

    fun decodeOriginal(context: Context, item: PhotoItem): Bitmap = decode(context, item.uri, null)

    fun thumbnailOf(bmp: Bitmap): Bitmap {
        val f = THUMB_SIDE.toFloat() / minOf(bmp.width, bmp.height)
        if (f >= 1f) return bmp.copy(Bitmap.Config.ARGB_8888, false)
        return Bitmap.createScaledBitmap(bmp, max(1, (bmp.width * f).roundToInt()), max(1, (bmp.height * f).roundToInt()), true)
    }

    fun loadThumb(context: Context, item: PhotoItem): Bitmap =
        decode(context, item.uri, item.versions.lastOrNull(), THUMB_SIDE * 2).let { full ->
            thumbnailOf(full).also { if (it !== full) full.recycle() }
        }

    /** Stores a new edited version of [item] in the cache (JPEG q100, visually lossless). */
    fun addVersion(context: Context, item: PhotoItem, bmp: Bitmap) {
        val dir = File(context.cacheDir, "edits").apply { mkdirs() }
        val file = File(dir, "p${item.id}_${System.nanoTime()}.jpg")
        file.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 100, it) }
        item.versions.add(file)
        while (item.versions.size > MAX_VERSIONS) item.versions.removeAt(0).delete()
    }

    /** Drops the newest version. Returns false when there was nothing to undo. */
    fun undo(item: PhotoItem): Boolean {
        if (item.versions.isEmpty()) return false
        item.versions.removeAt(item.versions.size - 1).delete()
        return true
    }

    fun clearCache(context: Context) {
        File(context.cacheDir, "edits").deleteRecursively()
    }

    /** Copies the latest edit of [item] into Pictures/WatermarkEraser. */
    fun saveToGallery(context: Context, item: PhotoItem): Uri? {
        val src = item.versions.lastOrNull() ?: return null
        val name = "clean_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + "_${item.id}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/WatermarkEraser")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            resolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
            values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null); null
        }
    }
}
