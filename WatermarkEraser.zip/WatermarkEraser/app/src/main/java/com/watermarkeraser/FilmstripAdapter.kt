package com.watermarkeraser

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.watermarkeraser.databinding.ItemAddBinding
import com.watermarkeraser.databinding.ItemPhotoBinding

/** Horizontal strip of photo thumbnails with status badges, plus an "add" tile at the end. */
class FilmstripAdapter(
    private val items: List<PhotoItem>,
    private val onSelect: (Int) -> Unit,
    private val onLongPress: (Int) -> Unit,
    private val onAdd: () -> Unit,
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var selected = 0
        set(value) {
            val old = field
            field = value
            if (old in items.indices) notifyItemChanged(old)
            if (value in items.indices) notifyItemChanged(value)
        }

    var locked = false

    init { setHasStableIds(true) }

    override fun getItemId(position: Int): Long = if (position < items.size) items[position].id else -1L
    override fun getItemCount() = items.size + 1
    override fun getItemViewType(position: Int) = if (position < items.size) TYPE_PHOTO else TYPE_ADD

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_PHOTO) PhotoVH(ItemPhotoBinding.inflate(inf, parent, false))
        else AddVH(ItemAddBinding.inflate(inf, parent, false))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is AddVH -> holder.b.addTile.setOnClickListener { if (!locked) onAdd() }
            is PhotoVH -> {
                val item = items[position]
                val b = holder.b
                b.thumb.setImageBitmap(item.thumb)
                b.selectedRing.visibility = if (position == selected) View.VISIBLE else View.GONE
                val working = item.state == PhotoItem.State.WORKING
                b.working.visibility = if (working) View.VISIBLE else View.GONE
                b.dim.visibility = if (working) View.VISIBLE else View.GONE
                when (item.state) {
                    PhotoItem.State.CLEANED, PhotoItem.State.SAVED -> {
                        b.badge.visibility = View.VISIBLE
                        b.badge.setBackgroundResource(R.drawable.bg_badge_success)
                        b.badge.setImageResource(R.drawable.ic_check)
                    }
                    PhotoItem.State.NOT_FOUND -> {
                        b.badge.visibility = View.VISIBLE
                        b.badge.setBackgroundResource(R.drawable.bg_badge_warning)
                        b.badge.setImageDrawable(null)
                    }
                    else -> b.badge.visibility = View.GONE
                }
                b.root.setOnClickListener {
                    val p = holder.bindingAdapterPosition
                    if (!locked && p != RecyclerView.NO_POSITION) onSelect(p)
                }
                b.root.setOnLongClickListener {
                    val p = holder.bindingAdapterPosition
                    if (!locked && p != RecyclerView.NO_POSITION) { onLongPress(p); true } else false
                }
            }
        }
    }

    class PhotoVH(val b: ItemPhotoBinding) : RecyclerView.ViewHolder(b.root)
    class AddVH(val b: ItemAddBinding) : RecyclerView.ViewHolder(b.root)

    companion object {
        private const val TYPE_PHOTO = 0
        private const val TYPE_ADD = 1
    }
}
