package com.watermarkeraser

import android.annotation.SuppressLint
import android.app.RecoverableSecurityException
import android.content.Intent
import android.content.IntentSender
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.IntentCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.watermarkeraser.core.Inpainter
import com.watermarkeraser.core.MaskCodec
import com.watermarkeraser.core.WatermarkDetector
import com.watermarkeraser.databinding.ActivityMainBinding
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var strip: FilmstripAdapter

    private val items = ArrayList<PhotoItem>()
    private var current = -1                 // index of the open photo
    private var original: Bitmap? = null     // untouched version of the open photo, for hold-to-compare
    private var busy = false
    private val hideStatus = Runnable { fadeOutStatus() }

    private var pendingSystemAsk: CompletableDeferred<Boolean>? = null
    private val systemAsk = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        pendingSystemAsk?.complete(res.resultCode == RESULT_OK)
        pendingSystemAsk = null
    }

    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private var deleteOriginals: Boolean
        get() = prefs.getBoolean(KEY_DELETE_ORIGINALS, true)
        set(v) { prefs.edit().putBoolean(KEY_DELETE_ORIGINALS, v).apply() }

    private val pickPhotos = registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(MAX_PICK)) { uris ->
        if (uris.isNotEmpty()) addPhotos(uris)
    }

    // ───────────────────────── Setup ─────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }
        if (savedInstanceState == null) Photos.clearCache(this)

        b.canvasCard.clipToOutline = true
        val dp = resources.displayMetrics.density
        b.editor.fitInsets = floatArrayOf(12 * dp, 60 * dp, 12 * dp, 76 * dp)
        b.editor.onMaskEdited = { render() }

        strip = FilmstripAdapter(items, onSelect = { open(it) }, onLongPress = { removePhoto(it) }, onAdd = { pick() })
        b.filmstrip.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        b.filmstrip.adapter = strip
        b.filmstrip.itemAnimator?.changeDuration = 120

        b.btnEmptyPick.setOnClickListener { pick() }
        b.btnErase.setOnClickListener { erase() }
        b.btnUndo.setOnClickListener { undo() }
        b.btnDetect.setOnClickListener { detect() }
        b.btnClearMask.setOnClickListener { haptic(); b.editor.clearMask(); render() }
        b.btnGrow.setOnClickListener {
            if (busy) return@setOnClickListener
            if (b.editor.growMask()) { haptic(); setStatus(getString(R.string.status_grown), autoHide = true) }
            else setStatus(getString(R.string.paint_first), autoHide = true)
        }
        b.btnCleanAll.setOnClickListener { eraseAll() }
        b.btnSave.setOnClickListener { save() }
        b.btnShare.setOnClickListener { share() }
        b.btnMenu.setOnClickListener { showMenu(it) }
        pressScale(b.btnErase); pressScale(b.btnEmptyPick); pressScale(b.btnSave); pressScale(b.btnShare)

        b.toolMove.setOnClickListener { setTool(MaskEditorView.Mode.MOVE) }
        b.toolBrush.setOnClickListener { setTool(MaskEditorView.Mode.BRUSH) }
        b.toolEraser.setOnClickListener { setTool(MaskEditorView.Mode.ERASER) }
        b.brushSize.addOnChangeListener { _, value, _ -> b.editor.brushRadiusDp = value }
        b.editor.brushRadiusDp = b.brushSize.value
        setTool(MaskEditorView.Mode.BRUSH)
        setupCompare()

        if (savedInstanceState == null) handleShareIntent(intent)
        render()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShareIntent(intent)
    }

    private fun handleShareIntent(intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_SEND ->
                IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)?.let { addPhotos(listOf(it)) }
            Intent.ACTION_SEND_MULTIPLE ->
                IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
                    ?.takeIf { it.isNotEmpty() }?.let { addPhotos(it) }
        }
    }

    // ───────────────────────── Photos in the batch ─────────────────────────

    private fun pick() {
        if (busy) return
        pickPhotos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    private fun addPhotos(uris: List<Uri>) {
        val start = items.size
        val added = uris.map { PhotoItem(it) }
        items.addAll(added)
        strip.notifyItemRangeInserted(start, added.size)
        b.filmstrip.smoothScrollToPosition(start)
        render()
        lifecycleScope.launch {
            for (item in added) {
                item.thumb = withContext(Dispatchers.IO) { runCatching { Photos.loadThumb(this@MainActivity, item) }.getOrNull() }
                notifyItem(item)
            }
        }
        if (current < 0) open(start)
    }

    private fun open(index: Int) {
        if (busy || index !in items.indices) return
        if (index == current && b.editor.image != null) return
        val item = items[index]
        haptic()
        stashMask()          // keep what was painted on the photo we're leaving
        current = index
        strip.selected = index
        runTask(getString(R.string.status_loading)) {
            val (bmp, orig) = withContext(Dispatchers.IO) {
                val cur = Photos.decodeCurrent(this@MainActivity, item)
                cur to when {
                    !item.isEdited -> cur
                    item.originalDeleted -> null      // original is in the Trash; no before/after
                    else -> Photos.decodeOriginal(this@MainActivity, item)
                }
            }
            if (items.getOrNull(current) !== item) return@runTask   // photo was removed meanwhile
            original = orig
            b.editor.alpha = 0f
            b.editor.setImage(bmp)
            b.editor.clearMask()
            b.editor.animate().alpha(1f).setDuration(220).start()
            setStatus(null)
            val saved = item.mask?.let { MaskCodec.decode(it, bmp.width * bmp.height) }
            if (saved != null) {
                b.editor.setMask(saved)
                setStatus(getString(R.string.status_mask_restored), autoHide = true)
            } else if (item.state == PhotoItem.State.NEW) {
                detectInternal(item)
            }
        }
    }

    private fun removePhoto(index: Int) {
        if (busy || index !in items.indices) return
        haptic(strong = true)
        val item = items.removeAt(index)
        strip.notifyItemRemoved(index)
        when {
            items.isEmpty() -> {
                current = -1; original = null
                b.editor.clearImage()
                setStatus(null)
            }
            index == current -> { current = -1; open(min(index, items.size - 1)) }
            index < current -> { current--; strip.selected = current }
        }
        render()
        Snackbar.make(b.root, R.string.removed, Snackbar.LENGTH_LONG)
            .setAnchorView(b.bottomBar)
            .setAction(R.string.undo) {
                if (busy) return@setAction
                val at = min(index, items.size)
                items.add(at, item)
                strip.notifyItemInserted(at)
                if (current >= at) { current++; strip.selected = current }
                if (current < 0) open(at)
                render()
            }
            .show()
    }

    // ───────────────────────── Editing ─────────────────────────

    private fun detect() {
        val item = items.getOrNull(current) ?: return
        runTask(getString(R.string.status_detecting)) { detectInternal(item) }
    }

    private suspend fun detectInternal(item: PhotoItem) {
        val bmp = b.editor.image ?: return
        setStatus(getString(R.string.status_detecting))
        val det = withContext(Dispatchers.Default) {
            val px = IntArray(bmp.width * bmp.height)
            bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
            WatermarkDetector.detect(px, bmp.width, bmp.height)
        }
        if (items.getOrNull(current) !== item) return
        if (det == null) {
            if (item.state == PhotoItem.State.NEW) { item.state = PhotoItem.State.NOT_FOUND; notifyItem(item) }
            setStatus(getString(R.string.status_not_found))
        } else {
            b.editor.setMask(det.mask)
            b.editor.focusOn(det.box)
            setStatus(getString(R.string.status_found, zoneName(det.zone)))
            haptic()
        }
    }

    private fun erase() {
        val item = items.getOrNull(current) ?: return
        val bmp = b.editor.image ?: return
        val mask = b.editor.getMask() ?: return
        if (mask.none { it.toInt() != 0 }) {
            setStatus(getString(R.string.paint_first), autoHide = true)
            setTool(MaskEditorView.Mode.BRUSH)
            return
        }
        haptic()
        runTask(getString(R.string.status_erasing, 0), determinate = true) {
            val result = withContext(Dispatchers.Default) {
                val copy = bmp.copy(Bitmap.Config.ARGB_8888, true)
                inpaintInto(copy, mask) { pct ->
                    runOnUiThread {
                        b.progress.setProgressCompat(pct, true)
                        b.statusChip.text = getString(R.string.status_erasing, pct)
                    }
                }
                copy
            }
            withContext(Dispatchers.IO) {
                Photos.addVersion(this@MainActivity, item, result)
                item.thumb = Photos.thumbnailOf(result)
            }
            item.state = PhotoItem.State.CLEANED
            item.savedUri = null
            item.mask = null
            notifyItem(item)
            if (items.getOrNull(current) === item) {
                b.editor.setImage(result, keepView = true)
                b.editor.clearMask()
                b.editor.animate().alpha(0.55f).setDuration(70).withEndAction {
                    b.editor.animate().alpha(1f).setDuration(320).start()
                }.start()
            }
            haptic(strong = true)
            setStatus(getString(R.string.status_erased), autoHide = true)
        }
    }

    private fun undo() {
        val item = items.getOrNull(current) ?: return
        if (!item.isEdited) return
        if (item.originalDeleted && item.versions.size <= 1) {
            setStatus(getString(R.string.status_cant_undo_deleted), autoHide = true); return
        }
        haptic()
        runTask(getString(R.string.status_loading)) {
            val bmp = withContext(Dispatchers.IO) {
                Photos.undo(item)
                Photos.decodeCurrent(this@MainActivity, item).also { item.thumb = Photos.thumbnailOf(it) }
            }
            item.state = if (item.isEdited) PhotoItem.State.CLEANED else PhotoItem.State.NEW
            item.savedUri = null
            notifyItem(item)
            if (items.getOrNull(current) === item) {
                b.editor.setImage(bmp, keepView = true)
                b.editor.clearMask()
            }
            setStatus(getString(R.string.status_undone), autoHide = true)
        }
    }

    /**
     * Erases every photo that has a painted/detected red area waiting (using exactly that area),
     * plus every photo not processed yet (detecting its watermark automatically).
     */
    private fun eraseAll() {
        if (busy) return
        stashMask()
        val targets = items.filter { it.mask != null || it.state == PhotoItem.State.NEW }
        if (targets.isEmpty()) { setStatus(getString(R.string.status_nothing_to_clean), autoHide = true); return }
        haptic()
        runTask(getString(R.string.status_cleaning, 1, targets.size), determinate = true) {
            strip.locked = true
            var cleaned = 0; var missed = 0
            for ((k, item) in targets.withIndex()) {
                if (!items.contains(item)) continue
                setStatus(getString(R.string.status_cleaning, k + 1, targets.size))
                b.progress.setProgressCompat(k * 100 / targets.size, true)
                val before = item.state
                val painted = item.mask
                item.state = PhotoItem.State.WORKING
                notifyItem(item)
                try {
                    val result = withContext(Dispatchers.Default) {
                        val bmp = Photos.decodeCurrent(this@MainActivity, item)
                        val w = bmp.width; val h = bmp.height
                        val px = IntArray(w * h)
                        bmp.getPixels(px, 0, w, 0, 0, w, h)
                        // Your painted area wins; otherwise find the watermark automatically.
                        val mask = painted?.let { MaskCodec.decode(it, w * h) }
                            ?: WatermarkDetector.detect(px, w, h)?.mask
                        if (mask == null) null else {
                            Inpainter.inpaint(px, w, h, mask, inPlace = true)
                            bmp.setPixels(px, 0, w, 0, 0, w, h)
                            Photos.addVersion(this@MainActivity, item, bmp)
                            item.thumb = Photos.thumbnailOf(bmp)
                            bmp
                        }
                    }
                    if (result != null) {
                        item.state = PhotoItem.State.CLEANED; item.savedUri = null; item.mask = null; cleaned++
                        if (items.getOrNull(current) === item) { b.editor.setImage(result, keepView = true); b.editor.clearMask() }
                    } else {
                        item.state = if (before == PhotoItem.State.NEW) PhotoItem.State.NOT_FOUND else before
                        missed++
                    }
                } finally {
                    if (item.state == PhotoItem.State.WORKING) item.state = before
                    notifyItem(item)
                }
            }
            b.progress.setProgressCompat(100, true)
            haptic(strong = true)
            setStatus(
                if (missed == 0) getString(R.string.status_cleaned_all, cleaned)
                else getString(R.string.status_cleaned_some, cleaned, missed),
            )
        }
    }

    private fun inpaintInto(bmp: Bitmap, mask: ByteArray, progress: (Int) -> Unit) {
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        var last = -1
        Inpainter.inpaint(px, w, h, mask, inPlace = true) { f ->
            val p = (f * 100).toInt()
            if (p != last) { last = p; progress(p) }
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }

    // ───────────────────────── Save & share ─────────────────────────

    /** Saves every edited photo that isn't saved yet. Returns how many were saved now. */
    private suspend fun saveEdited(): Int {
        var n = 0
        for (item in items.filter { it.state == PhotoItem.State.CLEANED }) {
            val uri = withContext(Dispatchers.IO) { Photos.saveToGallery(this@MainActivity, item) } ?: continue
            item.savedUri = uri
            item.state = PhotoItem.State.SAVED
            notifyItem(item)
            n++
        }
        return n
    }

    private fun save() {
        if (items.none { it.isEdited }) { toast(R.string.nothing_to_save); return }
        runTask(getString(R.string.status_saving)) {
            saveEdited()
            val total = items.count { it.state == PhotoItem.State.SAVED }
            val saved = if (total > 1) getString(R.string.status_saved_many, total) else getString(R.string.status_saved)
            haptic(strong = true)
            if (!deleteOriginals) { setStatus(saved, autoHide = true); return@runTask }

            // Only originals whose cleaned copy is safely saved.
            val targets = items.filter { it.state == PhotoItem.State.SAVED && it.savedUri != null && !it.originalDeleted }
            if (targets.isEmpty()) { setStatus(saved, autoHide = true); return@runTask }
            setStatus(getString(R.string.status_deleting))
            val (deleted, unsupported, declined) = trashOriginals(targets)
            render()
            setStatus(
                when {
                    declined -> getString(R.string.status_saved_kept, saved)
                    unsupported > 0 && deleted > 0 -> getString(R.string.status_saved_some_deleted, saved, unsupported)
                    unsupported > 0 -> getString(R.string.status_saved_cant_delete, saved)
                    else -> getString(R.string.status_saved_deleted, saved)
                },
                autoHide = !declined && unsupported == 0,
            )
        }
    }

    /**
     * Moves the originals of [targets] to the Trash (Android 11+) or deletes them (Android 10).
     * Android always shows its own confirmation. Returns (done, not on this phone's gallery, user said no).
     */
    private suspend fun trashOriginals(targets: List<PhotoItem>): Triple<Int, Int, Boolean> {
        val pairs = targets.mapNotNull { item -> Photos.galleryUri(item.uri)?.let { item to it } }
        val unsupported = targets.size - pairs.size
        if (pairs.isEmpty()) return Triple(0, unsupported, false)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val request = MediaStore.createTrashRequest(contentResolver, pairs.map { it.second }, true)
            if (!askSystem(request.intentSender)) return Triple(0, unsupported, true)
            pairs.forEach { (item, _) -> item.originalDeleted = true }
            return Triple(pairs.size, unsupported, false)
        }

        // Android 10: delete one by one; the system asks for each photo the app didn't create.
        var done = 0; var declined = false
        for ((item, uri) in pairs) {
            val ok = try {
                withContext(Dispatchers.IO) { contentResolver.delete(uri, null, null) } > 0
            } catch (e: RecoverableSecurityException) {
                if (askSystem(e.userAction.actionIntent.intentSender)) {
                    runCatching { withContext(Dispatchers.IO) { contentResolver.delete(uri, null, null) } > 0 }.getOrDefault(false)
                } else { declined = true; false }
            } catch (e: SecurityException) { false }
            if (ok) { item.originalDeleted = true; done++ }
            if (declined) break
        }
        return Triple(done, unsupported, declined && done == 0)
    }

    /** Shows a system confirmation (e.g. "Allow Eraser to move this photo to trash?") and waits for the answer. */
    private suspend fun askSystem(sender: IntentSender): Boolean {
        val answer = CompletableDeferred<Boolean>()
        pendingSystemAsk = answer
        systemAsk.launch(IntentSenderRequest.Builder(sender).build())
        return answer.await()
    }

    /** Clears the current photos and opens the picker for a fresh batch (asks first if work would be lost). */
    private fun confirmNewBatch() {
        if (busy) return
        stashMask()
        val unsaved = items.count { it.state == PhotoItem.State.CLEANED }
        val pending = items.count { it.mask != null }
        if (unsaved == 0 && pending == 0) { startNewBatch(); return }
        val parts = ArrayList<String>()
        if (unsaved > 0) parts.add(resources.getQuantityString(R.plurals.unsaved_photos, unsaved, unsaved))
        if (pending > 0) parts.add(resources.getQuantityString(R.plurals.pending_photos, pending, pending))
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.new_batch_title)
            .setMessage(getString(R.string.new_batch_message, parts.joinToString("\n")))
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.new_batch_confirm) { _, _ -> startNewBatch() }
            .show()
    }

    private fun startNewBatch() {
        val n = items.size
        items.clear()
        strip.notifyItemRangeRemoved(0, n)
        current = -1
        original = null
        strip.selected = -1
        b.editor.clearImage()
        Photos.clearCache(this)
        setStatus(null)
        render()
        pick()
    }

    private fun showMenu(anchor: View) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, MENU_NEW_BATCH, 0, R.string.menu_new_batch).isEnabled = items.isNotEmpty() && !busy
        menu.menu.add(0, MENU_DELETE_ORIGINALS, 1, R.string.menu_delete_originals).apply {
            isCheckable = true
            isChecked = deleteOriginals
        }
        menu.setOnMenuItemClickListener { mi ->
            if (mi.itemId == MENU_NEW_BATCH) {
                confirmNewBatch()
                true
            } else if (mi.itemId == MENU_DELETE_ORIGINALS) {
                deleteOriginals = !deleteOriginals
                setStatus(
                    getString(if (deleteOriginals) R.string.status_delete_on else R.string.status_delete_off),
                    autoHide = true,
                )
                true
            } else false
        }
        menu.show()
    }

    private fun share() {
        if (items.none { it.isEdited }) { toast(R.string.nothing_to_save); return }
        runTask(getString(R.string.status_saving)) {
            saveEdited()
            val uris = ArrayList(items.mapNotNull { it.savedUri })
            if (uris.isEmpty()) { setStatus(getString(R.string.status_save_failed)); return@runTask }
            val send = if (uris.size == 1) {
                Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            }
            send.type = "image/jpeg"
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, getString(R.string.share)))
            setStatus(null)
        }
    }

    // ───────────────────────── UI helpers ─────────────────────────

    private fun setTool(mode: MaskEditorView.Mode) {
        b.editor.mode = mode
        b.toolMove.isSelected = mode == MaskEditorView.Mode.MOVE
        b.toolBrush.isSelected = mode == MaskEditorView.Mode.BRUSH
        b.toolEraser.isSelected = mode == MaskEditorView.Mode.ERASER
        b.brushSize.alpha = if (mode == MaskEditorView.Mode.MOVE) 0.35f else 1f
        b.brushSize.isEnabled = mode != MaskEditorView.Mode.MOVE
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupCompare() {
        b.btnCompare.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    b.editor.compareImage = original
                    b.statusChip.removeCallbacks(hideStatus)
                    b.statusChip.text = getString(R.string.status_original)
                    b.statusChip.visibility = View.VISIBLE
                    b.statusChip.alpha = 1f
                    haptic()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    b.editor.compareImage = null
                    fadeOutStatus()
                }
            }
            true
        }
    }

    /** Refreshes visibility, labels and enabled states. */
    private fun render() {
        val hasPhotos = items.isNotEmpty()
        val item = items.getOrNull(current)
        val hasImage = b.editor.image != null && item != null

        b.emptyState.visibility = if (hasPhotos) View.GONE else View.VISIBLE
        b.toolPill.visibility = if (hasImage) View.VISIBLE else View.GONE
        b.btnCompare.visibility =
            if (hasImage && item?.isEdited == true && original != null && original !== b.editor.image) View.VISIBLE else View.GONE
        b.stripSection.visibility = if (hasPhotos) View.VISIBLE else View.GONE
        b.bottomBar.visibility = if (hasPhotos) View.VISIBLE else View.INVISIBLE
        b.stripTitle.text = getString(R.string.strip_title, items.size)
        b.btnCleanAll.visibility = if (items.size > 1) View.VISIBLE else View.GONE

        val cleaned = items.count { it.isEdited }
        b.subtitle.text = when {
            !hasPhotos -> getString(R.string.subtitle_empty)
            items.size == 1 && hasImage -> getString(R.string.subtitle_single, b.editor.image!!.width, b.editor.image!!.height)
            items.size == 1 -> getString(R.string.subtitle_empty)
            else -> getString(R.string.subtitle_many, current + 1, items.size, cleaned)
        }
        b.saveLabel.text = getString(if (items.size > 1) R.string.save_all else R.string.save)

        strip.locked = busy
        enable(b.btnUndo, !busy && item?.isEdited == true)
        enable(b.btnDetect, !busy && hasImage)
        enable(b.btnClearMask, !busy && hasImage)
        enable(b.btnGrow, !busy && hasImage)
        enable(b.btnErase, !busy && hasImage)
        enable(b.btnSave, !busy && cleaned > 0)
        enable(b.btnShare, !busy && cleaned > 0)
        enable(b.btnCleanAll, !busy)
        enable(b.btnEmptyPick, !busy)
    }

    private fun enable(v: View, on: Boolean) {
        v.isEnabled = on
        v.animate().alpha(if (on) 1f else 0.35f).setDuration(150).start()
    }

    /** Remembers the open photo's red area on its PhotoItem, so it survives switching photos. */
    private fun stashMask() {
        val item = items.getOrNull(current) ?: return
        val img = b.editor.image ?: return
        val m = b.editor.getMask() ?: return
        if (m.size != img.width * img.height) return
        val had = item.mask != null
        item.mask = if (m.any { it.toInt() != 0 }) MaskCodec.encode(m) else null
        if (had || item.mask != null) notifyItem(item)
    }

    private fun notifyItem(item: PhotoItem) {
        val i = items.indexOf(item)
        if (i >= 0) strip.notifyItemChanged(i)
    }

    private fun setStatus(text: String?, autoHide: Boolean = false) {
        val chip = b.statusChip
        chip.removeCallbacks(hideStatus)
        if (text == null) { fadeOutStatus(); return }
        val wasVisible = chip.visibility == View.VISIBLE && chip.alpha > 0.9f
        chip.text = text
        chip.visibility = View.VISIBLE
        if (!wasVisible) {
            chip.alpha = 0f; chip.translationY = -8f
            chip.animate().alpha(1f).translationY(0f).setDuration(200).start()
        }
        if (autoHide) chip.postDelayed(hideStatus, 3500)
    }

    private fun fadeOutStatus() {
        val chip = b.statusChip
        if (chip.visibility != View.VISIBLE) return
        chip.animate().alpha(0f).setDuration(200).withEndAction { chip.visibility = View.GONE }.start()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun pressScale(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
            }
            false
        }
    }

    private fun haptic(strong: Boolean = false) {
        val type = when {
            strong && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R -> HapticFeedbackConstants.CONFIRM
            else -> HapticFeedbackConstants.CLOCK_TICK
        }
        b.root.performHapticFeedback(type)
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    private fun zoneName(zone: WatermarkDetector.Zone) = getString(
        when (zone) {
            WatermarkDetector.Zone.BOTTOM_RIGHT -> R.string.zone_br
            WatermarkDetector.Zone.BOTTOM_LEFT -> R.string.zone_bl
            WatermarkDetector.Zone.TOP_RIGHT -> R.string.zone_tr
            WatermarkDetector.Zone.TOP_LEFT -> R.string.zone_tl
            WatermarkDetector.Zone.BOTTOM_CENTER -> R.string.zone_bc
            WatermarkDetector.Zone.OTHER -> R.string.zone_other
        },
    )

    /** Runs a task with the progress bar shown and controls disabled; reports errors in the status chip. */
    private fun runTask(status: String, determinate: Boolean = false, block: suspend () -> Unit) {
        if (busy) return
        busy = true
        b.progress.isIndeterminate = !determinate
        if (determinate) b.progress.progress = 0
        b.progress.visibility = View.VISIBLE
        setStatus(status)
        render()
        lifecycleScope.launch {
            try {
                block()
            } catch (e: OutOfMemoryError) {
                setStatus(getString(R.string.status_oom))
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                setStatus(getString(R.string.status_error, e.message ?: e.javaClass.simpleName))
            } finally {
                busy = false
                b.progress.visibility = View.INVISIBLE
                render()
            }
        }
    }

    companion object {
        private const val MAX_PICK = 50
        private const val KEY_DELETE_ORIGINALS = "delete_originals"
        private const val MENU_DELETE_ORIGINALS = 1
        private const val MENU_NEW_BATCH = 2
    }
}
