package com.watermarkeraser

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.IntentCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.watermarkeraser.core.Inpainter
import com.watermarkeraser.core.WatermarkDetector
import com.watermarkeraser.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val history = ArrayDeque<Bitmap>()   // for undo
    private var savedUri: Uri? = null            // last saved copy of the current image
    private var busy = false

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) loadImage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        b.btnPick.setOnClickListener { pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
        b.btnEmptyPick.setOnClickListener { b.btnPick.performClick() }
        b.btnDetect.setOnClickListener { detect() }
        b.btnErase.setOnClickListener { erase() }
        b.btnUndo.setOnClickListener { undo() }
        b.btnSave.setOnClickListener { save(share = false) }
        b.btnShare.setOnClickListener { save(share = true) }
        b.btnClearMask.setOnClickListener { b.editor.clearMask(); updateButtons() }

        b.toolGroup.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            b.editor.mode = when (id) {
                R.id.toolMove -> MaskEditorView.Mode.MOVE
                R.id.toolEraser -> MaskEditorView.Mode.ERASER
                else -> MaskEditorView.Mode.BRUSH
            }
        }
        b.toolGroup.check(R.id.toolBrush)
        b.brushSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { b.editor.brushRadiusDp = 4f + p }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        b.brushSize.progress = 14
        b.editor.onMaskEdited = { updateButtons() }

        // Opened via "Share" from the gallery?
        if (savedInstanceState == null && intent?.action == Intent.ACTION_SEND) {
            IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)?.let { loadImage(it) }
        }
        updateButtons()
    }

    private fun loadImage(uri: Uri) = runTask(getString(R.string.status_loading)) {
        val bmp = withContext(Dispatchers.IO) {
            val source = ImageDecoder.createSource(contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                decoder.isMutableRequired = true
                val w = info.size.width; val h = info.size.height
                val longest = max(w, h)
                if (longest > MAX_SIDE) {
                    val f = MAX_SIDE.toFloat() / longest
                    decoder.setTargetSize((w * f).roundToInt(), (h * f).roundToInt())
                }
            }.let { if (it.config != Bitmap.Config.ARGB_8888) it.copy(Bitmap.Config.ARGB_8888, true) else it }
        }
        history.clear()
        savedUri = null
        b.emptyState.visibility = View.GONE
        b.editor.setImage(bmp)
        b.editor.clearMask()
        detectInternal()
    }

    private fun detect() = runTask(getString(R.string.status_detecting)) { detectInternal() }

    private suspend fun detectInternal() {
        val bmp = b.editor.image ?: return
        setStatus(getString(R.string.status_detecting))
        val det = withContext(Dispatchers.Default) {
            val px = IntArray(bmp.width * bmp.height)
            bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
            WatermarkDetector.detect(px, bmp.width, bmp.height)
        }
        if (det == null) {
            setStatus(getString(R.string.status_not_found))
        } else {
            b.editor.setMask(det.mask)
            b.editor.focusOn(det.box)
            val where = when (det.zone) {
                WatermarkDetector.Zone.BOTTOM_RIGHT -> getString(R.string.zone_br)
                WatermarkDetector.Zone.BOTTOM_LEFT -> getString(R.string.zone_bl)
                WatermarkDetector.Zone.TOP_RIGHT -> getString(R.string.zone_tr)
                WatermarkDetector.Zone.TOP_LEFT -> getString(R.string.zone_tl)
                WatermarkDetector.Zone.BOTTOM_CENTER -> getString(R.string.zone_bc)
                WatermarkDetector.Zone.OTHER -> getString(R.string.zone_other)
            }
            setStatus(getString(R.string.status_found, where))
        }
    }

    private fun erase() {
        val bmp = b.editor.image ?: return
        val mask = b.editor.getMask() ?: return
        if (mask.none { it.toInt() != 0 }) {
            Toast.makeText(this, R.string.paint_first, Toast.LENGTH_SHORT).show(); return
        }
        runTask(getString(R.string.status_erasing)) {
            b.progress.isIndeterminate = false
            val result = withContext(Dispatchers.Default) {
                val w = bmp.width; val h = bmp.height
                val px = IntArray(w * h)
                bmp.getPixels(px, 0, w, 0, 0, w, h)
                var lastPct = -1
                val out = Inpainter.inpaint(px, w, h, mask) { f ->
                    val pct = (f * 100).toInt()
                    if (pct != lastPct) { lastPct = pct; runOnUiThread { b.progress.progress = pct } }
                }
                val copy = bmp.copy(Bitmap.Config.ARGB_8888, true)
                copy.setPixels(out, 0, w, 0, 0, w, h)
                copy
            }
            history.addLast(bmp)
            while (history.size > MAX_UNDO) history.removeFirst()
            savedUri = null
            b.editor.setImage(result, keepView = true)
            b.editor.clearMask()
            setStatus(getString(R.string.status_erased))
        }
    }

    private fun undo() {
        val prev = history.removeLastOrNull() ?: return
        savedUri = null
        b.editor.setImage(prev, keepView = true)
        b.editor.clearMask()
        setStatus(getString(R.string.status_undone))
        updateButtons()
    }

    private fun save(share: Boolean) {
        val bmp = b.editor.image ?: return
        runTask(getString(R.string.status_saving)) {
            val uri = savedUri ?: withContext(Dispatchers.IO) { writeToGallery(bmp) }.also { savedUri = it }
            if (uri == null) {
                setStatus(getString(R.string.status_save_failed)); return@runTask
            }
            if (share) {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "image/jpeg"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(send, getString(R.string.share)))
                setStatus(getString(R.string.status_saved))
            } else {
                setStatus(getString(R.string.status_saved))
                Toast.makeText(this@MainActivity, R.string.status_saved, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun writeToGallery(bmp: Bitmap): Uri? {
        val name = "clean_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/WatermarkEraser")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            uri
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null); null
        }
    }

    /** Runs a UI task with the progress bar shown and buttons disabled; reports errors. */
    private fun runTask(status: String, block: suspend () -> Unit) {
        if (busy) return
        busy = true
        setStatus(status)
        b.progress.isIndeterminate = true
        b.progress.visibility = View.VISIBLE
        updateButtons()
        lifecycleScope.launch {
            try {
                block()
            } catch (e: OutOfMemoryError) {
                setStatus(getString(R.string.status_oom))
            } catch (e: Exception) {
                setStatus(getString(R.string.status_error, e.message ?: e.javaClass.simpleName))
            } finally {
                busy = false
                b.progress.visibility = View.GONE
                updateButtons()
            }
        }
    }

    private fun setStatus(text: String) { b.status.text = text }

    private fun updateButtons() {
        val hasImage = b.editor.image != null
        b.btnPick.isEnabled = !busy
        b.btnDetect.isEnabled = !busy && hasImage
        b.btnErase.isEnabled = !busy && hasImage
        b.btnClearMask.isEnabled = !busy && hasImage
        b.btnUndo.isEnabled = !busy && history.isNotEmpty()
        b.btnSave.isEnabled = !busy && hasImage
        b.btnShare.isEnabled = !busy && hasImage
    }

    companion object {
        private const val MAX_SIDE = 4096
        private const val MAX_UNDO = 3
    }
}
