package com.watermarkeraser.core

import java.io.ByteArrayOutputStream

/**
 * Compact storage for masks (0/1 per pixel) using run-length encoding.
 * A full-resolution mask is ~12 MB raw but usually only a few KB encoded, so every photo in a
 * batch can keep its painted area in memory.
 */
object MaskCodec {

    fun encode(mask: ByteArray): ByteArray {
        val out = ByteArrayOutputStream(1024)
        var cur = 0
        var run = 0
        for (b in mask) {
            val v = if (b.toInt() != 0) 1 else 0
            if (v == cur) run++ else { writeVarint(out, run); cur = v; run = 1 }
        }
        writeVarint(out, run)
        return out.toByteArray()
    }

    /** Returns null if the data doesn't describe exactly [size] pixels (e.g. photo size changed). */
    fun decode(data: ByteArray, size: Int): ByteArray? {
        val out = ByteArray(size)
        var pos = 0
        var idx = 0
        var v = 0
        while (pos < data.size) {
            var run = 0; var shift = 0
            while (true) {
                if (pos >= data.size) return null
                val b = data[pos++].toInt() and 0xff
                run = run or ((b and 0x7f) shl shift)
                if (b and 0x80 == 0) break
                shift += 7
                if (shift > 28) return null
            }
            if (idx + run > size) return null
            if (v == 1) out.fill(1, idx, idx + run)
            idx += run
            v = 1 - v
        }
        return if (idx == size) out else null
    }

    private fun writeVarint(out: ByteArrayOutputStream, value: Int) {
        var v = value
        while (v >= 0x80) { out.write((v and 0x7f) or 0x80); v = v ushr 7 }
        out.write(v)
    }
}
