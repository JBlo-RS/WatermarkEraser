package com.watermarkeraser

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * Shows the photo with the removal mask on top (red). Supports:
 *  - pinch to zoom, two-finger drag to pan, double-tap to reset
 *  - one finger: pan (MOVE), paint the mask (BRUSH) or remove mask (ERASER)
 */
class MaskEditorView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null,
) : View(context, attrs) {

    enum class Mode { MOVE, BRUSH, ERASER }

    var mode = Mode.BRUSH
    /** Brush radius in screen dp, so it feels the same at any zoom. */
    var brushRadiusDp = 18f
    var onMaskEdited: (() -> Unit)? = null

    var image: Bitmap? = null
        private set
    var mask: Bitmap? = null
        private set

    private val viewMatrix = Matrix()
    private val inverse = Matrix()
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val maskPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply { color = context.getColor(R.color.mask) }

    /** Space (px) kept free around the fitted photo for floating controls: left, top, right, bottom. */
    var fitInsets = floatArrayOf(0f, 0f, 0f, 0f)

    /** When set, this bitmap (the original) is drawn instead of the edited photo, without the mask. */
    var compareImage: Bitmap? = null
        set(value) { field = value; invalidate() }
    private val cursorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f * resources.displayMetrics.density; color = Color.WHITE
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = Color.WHITE
    }
    private val clearMode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    private var maskCanvas: Canvas? = null

    private var lastX = 0f; private var lastY = 0f
    private var painting = false
    private var cursorX = -1f; private var cursorY = -1f
    private var multiTouch = false

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val current = currentScale()
            val fit = fitScale()
            val target = (current * d.scaleFactor).coerceIn(fit * 0.5f, fit * 20f)
            val f = target / current
            viewMatrix.postScale(f, f, d.focusX, d.focusY)
            invalidate()
            return true
        }
    })

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean { fit(); return true }
    })

    fun setImage(bmp: Bitmap, keepView: Boolean = false) {
        compareImage = null
        val sizeChanged = image?.width != bmp.width || image?.height != bmp.height
        image = bmp
        if (sizeChanged || mask == null) {
            mask = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ALPHA_8)
            maskCanvas = Canvas(mask!!)
        }
        if (!keepView || sizeChanged) fit()
        invalidate()
    }

    fun setMask(m: ByteArray) {
        val bmp = mask ?: return
        val stride = bmp.rowBytes
        val buf = ByteArray(stride * bmp.height)
        for (y in 0 until bmp.height) {
            val row = y * bmp.width
            for (x in 0 until bmp.width) if (m[row + x].toInt() != 0) buf[y * stride + x] = 0xff.toByte()
        }
        bmp.copyPixelsFromBuffer(java.nio.ByteBuffer.wrap(buf))
        invalidate()
    }

    /** Full-resolution mask as 0/1 bytes. */
    fun getMask(): ByteArray? {
        val bmp = mask ?: return null
        val stride = bmp.rowBytes
        val buf = java.nio.ByteBuffer.allocate(stride * bmp.height)
        bmp.copyPixelsToBuffer(buf)
        val raw = buf.array()
        val out = ByteArray(bmp.width * bmp.height)
        for (y in 0 until bmp.height) for (x in 0 until bmp.width) {
            if ((raw[y * stride + x].toInt() and 0xff) > 20) out[y * bmp.width + x] = 1
        }
        return out
    }

    fun hasMask(): Boolean = getMask()?.any { it.toInt() != 0 } == true

    fun clearMask() {
        mask?.eraseColor(Color.TRANSPARENT)
        invalidate()
    }

    fun fit() {
        val bmp = image ?: return
        if (width == 0 || height == 0) return
        viewMatrix.setRectToRect(
            RectF(0f, 0f, bmp.width.toFloat(), bmp.height.toFloat()),
            RectF(fitInsets[0], fitInsets[1], width - fitInsets[2], height - fitInsets[3]), Matrix.ScaleToFit.CENTER,
        )
        invalidate()
    }

    /** Zoom so that the given image-space box (l, t, r, b) is comfortably in view. */
    fun focusOn(box: IntArray) {
        val bmp = image ?: return
        if (width == 0 || height == 0) return
        val bw = (box[2] - box[0]).toFloat(); val bh = (box[3] - box[1]).toFloat()
        val padX = max(bw * 0.6f, bmp.width * 0.05f); val padY = max(bh * 1.5f, bmp.height * 0.05f)
        val src = RectF(
            max(0f, box[0] - padX), max(0f, box[1] - padY),
            min(bmp.width.toFloat(), box[2] + padX), min(bmp.height.toFloat(), box[3] + padY),
        )
        viewMatrix.setRectToRect(src, RectF(fitInsets[0], fitInsets[1], width - fitInsets[2], height - fitInsets[3]), Matrix.ScaleToFit.CENTER)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) { super.onSizeChanged(w, h, oldw, oldh); fit() }

    override fun onDraw(canvas: Canvas) {
        val bmp = image ?: return
        val cmp = compareImage
        if (cmp != null && cmp.width == bmp.width && cmp.height == bmp.height) {
            canvas.drawBitmap(cmp, viewMatrix, bitmapPaint)
            return
        }
        canvas.drawBitmap(bmp, viewMatrix, bitmapPaint)
        mask?.let { canvas.drawBitmap(it, viewMatrix, maskPaint) }
        if (cursorX >= 0 && mode != Mode.MOVE) {
            canvas.drawCircle(cursorX, cursorY, brushRadiusDp * resources.displayMetrics.density, cursorPaint)
        }
    }

    private fun currentScale(): Float { val v = FloatArray(9); viewMatrix.getValues(v); return v[Matrix.MSCALE_X] }

    private fun fitScale(): Float {
        val bmp = image ?: return 1f
        return min((width - fitInsets[0] - fitInsets[2]) / bmp.width, (height - fitInsets[1] - fitInsets[3]) / bmp.height)
    }

    /** Removes the photo (used when the last photo is removed from the batch). */
    fun clearImage() {
        image = null; mask = null; maskCanvas = null; compareImage = null
        invalidate()
    }

    private fun toImage(x: Float, y: Float): FloatArray {
        viewMatrix.invert(inverse)
        val p = floatArrayOf(x, y); inverse.mapPoints(p); return p
    }

    private fun paintSegment(x0: Float, y0: Float, x1: Float, y1: Float) {
        val c = maskCanvas ?: return
        val a = toImage(x0, y0); val b = toImage(x1, y1)
        strokePaint.strokeWidth = 2f * brushRadiusDp * resources.displayMetrics.density / currentScale()
        strokePaint.xfermode = if (mode == Mode.ERASER) clearMode else null
        if (a[0] == b[0] && a[1] == b[1]) {
            strokePaint.style = Paint.Style.FILL
            c.drawCircle(a[0], a[1], strokePaint.strokeWidth / 2f, strokePaint)
            strokePaint.style = Paint.Style.STROKE
        } else {
            c.drawLine(a[0], a[1], b[0], b[1], strokePaint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (image == null) return false
        scaleDetector.onTouchEvent(e)
        gestureDetector.onTouchEvent(e)

        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                multiTouch = false
                lastX = e.x; lastY = e.y
                painting = mode != Mode.MOVE
                if (painting) { paintSegment(e.x, e.y, e.x, e.y); cursorX = e.x; cursorY = e.y }
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                multiTouch = true; painting = false; cursorX = -1f
                lastX = focusX(e); lastY = focusY(e)
            }
            MotionEvent.ACTION_MOVE -> {
                if (multiTouch || mode == Mode.MOVE) {
                    val fx = focusX(e); val fy = focusY(e)
                    if (!scaleDetector.isInProgress || multiTouch) viewMatrix.postTranslate(fx - lastX, fy - lastY)
                    lastX = fx; lastY = fy
                } else if (painting) {
                    paintSegment(lastX, lastY, e.x, e.y)
                    lastX = e.x; lastY = e.y
                    cursorX = e.x; cursorY = e.y
                }
                invalidate()
            }
            MotionEvent.ACTION_POINTER_UP -> {
                // Re-anchor the pan on the remaining fingers.
                val skip = e.actionIndex
                var sx = 0f; var sy = 0f; var c = 0
                for (i in 0 until e.pointerCount) if (i != skip) { sx += e.getX(i); sy += e.getY(i); c++ }
                if (c > 0) { lastX = sx / c; lastY = sy / c }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (painting) onMaskEdited?.invoke()
                painting = false; cursorX = -1f
                invalidate()
            }
        }
        return true
    }

    private fun focusX(e: MotionEvent): Float { var s = 0f; for (i in 0 until e.pointerCount) s += e.getX(i); return s / e.pointerCount }
    private fun focusY(e: MotionEvent): Float { var s = 0f; for (i in 0 until e.pointerCount) s += e.getY(i); return s / e.pointerCount }
}
