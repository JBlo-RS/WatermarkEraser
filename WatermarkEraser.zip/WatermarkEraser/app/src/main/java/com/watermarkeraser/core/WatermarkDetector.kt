package com.watermarkeraser.core

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Finds a likely text watermark ("© Name", a URL, a studio name...) and returns a removal mask.
 *
 * How it works:
 *  1. Work on a downscaled grayscale copy (max side 1024).
 *  2. Strokes = pixels clearly brighter (or darker) than their local surroundings.
 *     Watermark text is one colour, so each polarity is searched separately.
 *  3. Stroke blobs are kept if they are glyph-shaped (sensible height, aspect ratio, fill).
 *  4. Glyphs of similar height sitting on the same line with letter-sized gaps are chained into
 *     text lines. Random photo texture rarely forms clean lines of aligned, similar glyphs.
 *  5. Lines are scored by glyph count, alignment, clutter around them and position: lines near a
 *     corner win, bottom-right most of all.
 *  6. The winning line's strokes are hole-filled, dilated (to cover anti-aliasing / drop shadows)
 *     and scaled back to full resolution.
 */
object WatermarkDetector {

    enum class Zone { BOTTOM_RIGHT, BOTTOM_LEFT, TOP_RIGHT, TOP_LEFT, BOTTOM_CENTER, OTHER }

    class Detection(
        /** Full-resolution mask, 1 = pixel to remove. */
        val mask: ByteArray,
        /** left, top, right, bottom (inclusive) in full-resolution pixels. */
        val box: IntArray,
        val zone: Zone,
        val score: Float,
    )

    private class Glyph(val c: ImageOps.Component) {
        val h = c.maxY - c.minY + 1
        val w = c.maxX - c.minX + 1
        val cy = (c.minY + c.maxY) / 2f
    }

    private class Line(val polarity: Int, val glyphs: List<Glyph>, val x0: Int, val y0: Int, val x1: Int, val y1: Int, val score: Float, val zone: Zone)

    fun detect(px: IntArray, w: Int, h: Int): Detection? {
        val s = min(1f, 1024f / max(w, h))
        val sw = max(16, (w * s).roundToInt())
        val sh = max(16, (h * s).roundToInt())
        val n = sw * sh
        val minDim = min(sw, sh)
        val g = ImageOps.downscaleGray(px, w, h, sw, sh)
        val blur = ImageOps.boxBlur(g, sw, sh, max(3, minDim / 45))
        val d = FloatArray(n) { g[it] - blur[it] }

        var mean = 0.0
        for (v in d) mean += abs(v)
        mean /= n
        var varSum = 0.0
        for (v in d) { val e = abs(v) - mean; varSum += e * e }
        val t = max(10.0, mean + 1.5 * sqrt(varSum / n)).toFloat()

        var best: Line? = null
        for (polarity in intArrayOf(1, -1)) {
            val bin = ByteArray(n) { if (d[it] * polarity > t) 1 else 0 }
            val line = bestLine(bin, sw, sh, polarity)
            if (line != null && (best == null || line.score > best.score)) best = line
        }
        if (best == null) return null

        // Mask: strokes of the chosen polarity inside the line's box.
        val bin = ByteArray(n) { if (d[it] * best.polarity > t * 0.7f) 1 else 0 }
        val mh = best.glyphs.maxOf { it.h }
        val meanH = best.glyphs.map { it.h }.average().toFloat()
        val meanCy = best.glyphs.map { it.cy }.average().toFloat()

        // Extend along the text line: letters touching photo detail (e.g. a pole behind a word)
        // fail the glyph test, so keep walking sideways while the line's core band has strokes.
        val coreY0 = max(0, (meanCy - meanH * 0.3f).toInt()); val coreY1 = min(sh - 1, (meanCy + meanH * 0.3f).toInt())
        val maxGap = (meanH * 1.5f).toInt()
        val maxExtend = ((best.x1 - best.x0) * 0.8f).toInt()
        val bandH = max(2, (meanH * 0.6f).toInt())
        val aboveY0 = max(0, best.y0 - 1 - bandH); val aboveY1 = max(0, best.y0 - 2)
        val belowY0 = min(sh - 1, best.y1 + 2); val belowY1 = min(sh - 1, best.y1 + 1 + bandH)
        fun any(x: Int, y0: Int, y1: Int): Boolean { for (y in y0..y1) if (bin[y * sw + x].toInt() != 0) return true; return false }
        // 1 = text-like column, 0 = empty, -1 = occluded by photo detail crossing the line
        fun classify(x: Int): Int = when {
            any(x, aboveY0, aboveY1) || any(x, belowY0, belowY1) -> -1
            any(x, coreY0, coreY1) -> 1
            else -> 0
        }
        fun extend(start: Int, step: Int): Int {
            var x = start + step; var lastHit = start; var gap = 0; var occluded = 0
            while (x in 0 until sw && abs(x - start) <= maxExtend && gap <= maxGap && occluded <= maxGap * 3) {
                when (classify(x)) {
                    1 -> { lastHit = x; gap = 0; occluded = 0 }
                    0 -> gap++
                    else -> occluded++
                }
                x += step
            }
            return lastHit
        }
        val lx0 = extend(best.x0, -1)
        val lx1 = extend(best.x1, 1)

        val pad = max(2, mh / 4)
        val cx0 = max(0, lx0 - pad); val cy0 = max(0, best.y0 - pad)
        val cx1 = min(sw, lx1 + 1 + pad); val cy1 = min(sh, best.y1 + 1 + pad)
        var small = ByteArray(n)
        for (y in cy0 until cy1) for (x in cx0 until cx1) small[y * sw + x] = bin[y * sw + x]
        small = ImageOps.dilate(small, sw, sh, 1)
        ImageOps.fillHoles(small, sw, cx0, cy0, cx1, cy1)
        small = ImageOps.dilate(small, sw, sh, max(2, mh / 6))

        // Scale to full resolution.
        val inv = 1f / s
        val fx0 = max(0, ((cx0 - 4) * inv).toInt()); val fy0 = max(0, ((cy0 - 4) * inv).toInt())
        val fx1 = min(w, ceil((cx1 + 4) * inv).toInt()); val fy1 = min(h, ceil((cy1 + 4) * inv).toInt())
        var full = ByteArray(w * h)
        for (y in fy0 until fy1) {
            val sy = min(sh - 1, (y * s).toInt())
            for (x in fx0 until fx1) full[y * w + x] = small[sy * sw + min(sw - 1, (x * s).toInt())]
        }
        if (inv > 1.01f) full = ImageOps.dilate(full, w, h, ceil(inv).toInt())

        var l = w; var tp = h; var rt = -1; var bt = -1
        for (y in fy0 until fy1) for (x in fx0 until fx1) if (full[y * w + x].toInt() != 0) {
            if (x < l) l = x; if (x > rt) rt = x
            if (y < tp) tp = y; if (y > bt) bt = y
        }
        if (rt < 0) return null
        return Detection(full, intArrayOf(l, tp, rt, bt), best.zone, best.score)
    }

    private fun bestLine(bin: ByteArray, w: Int, h: Int, polarity: Int): Line? {
        val minDim = min(w, h)
        val minH = max(4, (minDim * 0.008f).toInt())
        val maxH = (minDim * 0.12f).toInt()
        val glyphs = ImageOps.components(bin, w, 0, 0, w, h).mapNotNull { c ->
            val gw = c.maxX - c.minX + 1; val gh = c.maxY - c.minY + 1
            val fill = c.count.toFloat() / (gw * gh)
            if (c.count >= 6 && gh in minH..maxH && gw <= gh * 6 + 4 && fill in 0.08f..0.85f) Glyph(c) else null
        }.sortedBy { it.c.minX }
        if (glyphs.size < 3) return null

        // Union-find: chain glyphs that look like neighbouring letters on one line.
        val parent = IntArray(glyphs.size) { it }
        fun find(i: Int): Int { var x = i; while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x] }; return x }
        for (i in glyphs.indices) {
            val a = glyphs[i]
            for (j in i + 1 until glyphs.size) {
                val b = glyphs[j]
                val mh = max(a.h, b.h)
                if (b.c.minX - a.c.maxX > mh * 1.2f) break // sorted by minX: nothing further can be closer
                if (max(a.h, b.h) > min(a.h, b.h) * 2.2f) continue
                if (abs(a.cy - b.cy) > mh * 0.6f) continue
                if (b.c.minX - a.c.maxX < -mh) continue // heavily overlapping horizontally: not side by side
                parent[find(j)] = find(i)
            }
        }
        val groups = HashMap<Int, MutableList<Glyph>>()
        for (i in glyphs.indices) groups.getOrPut(find(i)) { ArrayList() }.add(glyphs[i])

        var best: Line? = null
        for (members in groups.values) {
            if (members.size < 3) continue
            val x0 = members.minOf { it.c.minX }; val x1 = members.maxOf { it.c.maxX }
            val y0 = members.minOf { it.c.minY }; val y1 = members.maxOf { it.c.maxY }
            if (x1 - x0 > w * 0.9f) continue
            val meanH = members.map { it.h }.average().toFloat()
            val meanCy = members.map { it.cy }.average().toFloat()
            val cyStd = sqrt(members.map { (it.cy - meanCy) * (it.cy - meanCy) }.average().toFloat())

            // Clutter: stroke pixels in/around the line's box that are not part of the line.
            val m = (meanH * 0.5f).toInt()
            val bx0 = max(0, x0 - m); val by0 = max(0, y0 - m); val bx1 = min(w - 1, x1 + m); val by1 = min(h - 1, y1 + m)
            var strokes = 0
            for (y in by0..by1) for (x in bx0..bx1) strokes += bin[y * w + x]
            val own = members.sumOf { it.c.count }
            val clutter = max(0, strokes - own).toFloat() / own

            val (zone, posWeight) = position((x0 + x1) / 2f / w, (y0 + y1) / 2f / h)
            val score = members.size.toFloat() * posWeight / (1f + 3f * cyStd / meanH) / (1f + 2f * clutter)
            if (best == null || score > best.score) best = Line(polarity, members, x0, y0, x1, y1, score, zone)
        }
        return best
    }

    /** Weight for where a candidate sits: corners (bottom-right most of all) are typical watermark spots. */
    private fun position(nx: Float, ny: Float): Pair<Zone, Float> {
        val options = listOf(
            Triple(Zone.BOTTOM_RIGHT, hypot(1f - nx, 1f - ny), 1.0f),
            Triple(Zone.BOTTOM_LEFT, hypot(nx, 1f - ny), 0.7f),
            Triple(Zone.TOP_RIGHT, hypot(1f - nx, ny), 0.65f),
            Triple(Zone.TOP_LEFT, hypot(nx, ny), 0.6f),
            Triple(Zone.BOTTOM_CENTER, hypot(0.5f - nx, 1f - ny), 0.6f),
        )
        var bestZone = Zone.OTHER; var bestW = 0.15f
        for ((zone, dist, weight) in options) {
            val wgt = weight * max(0f, 1f - dist * 1.6f)
            if (wgt > bestW) { bestW = wgt; bestZone = zone }
        }
        return bestZone to bestW
    }
}
