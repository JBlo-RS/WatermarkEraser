package com.watermarkeraser.core

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Finds a likely watermark (text, optionally with a logo or a second line) and returns a removal mask.
 *
 * How it works:
 *  1. Work on a downscaled grayscale copy (max side 1024).
 *  2. Strokes = pixels clearly brighter (or darker) than their local surroundings.
 *     Watermark text is one colour, so each polarity is searched separately.
 *  3. Stroke blobs are kept if they are glyph-shaped (sensible height, aspect ratio, fill).
 *  4. Glyphs of similar height on the same baseline with letter-sized gaps are chained into lines.
 *  5. Lines are scored by glyph count, alignment, clutter, colour (watermarks wash colour out,
 *     photo texture doesn't) and position: lines near a corner win, bottom-right most of all.
 *  6. The winning line is grown into the whole watermark: neighbouring text lines (a website
 *     under a name), logos/symbols beside it, and faint letters at a lower threshold.
 *  7. Strokes in that area are hole-filled, dilated generously (anti-aliasing, glow, shadow)
 *     and scaled back to full resolution.
 */
object WatermarkDetector {

    enum class Zone { BOTTOM_RIGHT, BOTTOM_LEFT, TOP_RIGHT, TOP_LEFT, BOTTOM_CENTER, OTHER }

    class Detection(
        /** Full-resolution mask, 1 = pixel to remove. */
        val mask: ByteArray,
        /** left, top, right, bottom (inclusive) in full-resolution pixels. */
        val box: IntArray,
        val zone: Zone,
        val score: Float,
    )

    private class Glyph(val c: ImageOps.Component) {
        val h = c.maxY - c.minY + 1
        val w = c.maxX - c.minX + 1
        val cy = (c.minY + c.maxY) / 2f
    }

    private class Line(
        val polarity: Int, val glyphs: List<Glyph>,
        val x0: Int, val y0: Int, val x1: Int, val y1: Int,
        val meanH: Float, val meanCy: Float, val score: Float, val zone: Zone,
        val clutter: Float, val colourWeight: Float, val contrast: Float,
    )

    /** Optional diagnostics sink (used by desktop tests). */
    var debug: ((String) -> Unit)? = null

    private class Box(var x0: Int, var y0: Int, var x1: Int, var y1: Int) {
        fun gapTo(c: ImageOps.Component): Pair<Int, Int> =
            max(0, max(c.minX - x1, x0 - c.maxX)) to max(0, max(c.minY - y1, y0 - c.maxY))
        fun add(c: ImageOps.Component) { x0 = min(x0, c.minX); y0 = min(y0, c.minY); x1 = max(x1, c.maxX); y1 = max(y1, c.maxY) }
        fun add(l: Line) { x0 = min(x0, l.x0); y0 = min(y0, l.y0); x1 = max(x1, l.x1); y1 = max(y1, l.y1) }
    }

    fun detect(px: IntArray, w: Int, h: Int): Detection? {
        val s = min(1f, 1024f / max(w, h))
        val sw = max(16, (w * s).roundToInt())
        val sh = max(16, (h * s).roundToInt())
        val n = sw * sh
        val minDim = min(sw, sh)
        val g = ImageOps.downscaleGray(px, w, h, sw, sh)
        val blur = ImageOps.boxBlur(g, sw, sh, max(3, minDim / 45))
        val d = FloatArray(n) { g[it] - blur[it] }
        val chroma = ImageOps.downscaleChroma(px, w, h, sw, sh)
        val chromaBg = ImageOps.boxBlur(chroma, sw, sh, max(4, minDim / 25))

        var mean = 0.0
        for (v in d) mean += abs(v)
        mean /= n
        var varSum = 0.0
        for (v in d) { val e = abs(v) - mean; varSum += e * e }
        val t = max(10.0, mean + 1.5 * sqrt(varSum / n)).toFloat()

        var best: Line? = null
        var bestLines: List<Line> = emptyList()
        for (polarity in intArrayOf(1, -1)) {
            val bin = ByteArray(n) { if (d[it] * polarity > t) 1 else 0 }
            val lines = findLines(bin, sw, sh, polarity, chroma, chromaBg, d, t)
            debug?.let { log -> lines.sortedByDescending { it.score }.take(3).forEach { log("  cand pol=$polarity n=${it.glyphs.size} box=${it.x0},${it.y0}-${it.x1},${it.y1} score=${it.score} clutter=${it.clutter} colour=${it.colourWeight} contrast=${it.contrast} zone=${it.zone}") } }
            val top = lines.maxByOrNull { it.score } ?: continue
            if (top.score > 0f && (best == null || top.score > best.score)) { best = top; bestLines = lines }
        }
        if (best == null) return null
        debug?.let { log ->
            bestLines.sortedByDescending { it.score }.take(6).forEach {
                log("line pol=${it.polarity} n=${it.glyphs.size} box=${it.x0},${it.y0}-${it.x1},${it.y1} h=${it.meanH} score=${it.score} clutter=${it.clutter} colour=${it.colourWeight} contrast=${it.contrast}")
            }
        }

        val pol = best.polarity
        val lineH = best.meanH
        val area = Box(best.x0, best.y0, best.x1, best.y1)
        // Tight rectangles around every recognised piece (text lines, logo blobs, extra letters).
        // The mask is built only from these, so photo texture between them is left alone.
        val pieces = ArrayList<IntArray>().apply { add(intArrayOf(best.x0, best.y0, best.x1, best.y1)) }

        // ── Grow 1: other text lines stacked above/below (e.g. a website under a name) ──
        var grew = true
        val used = HashSet<Line>().apply { add(best) }
        while (grew) {
            grew = false
            for (l in bestLines) {
                if (l in used || l.glyphs.size < 2 || used.size >= 4) continue
                // must itself look like watermark text: calm surroundings, washed-out colour, similar crispness
                if (l.clutter > 1f || l.colourWeight < 0.7f) continue
                if (max(l.contrast, best.contrast) / max(1f, min(l.contrast, best.contrast)) > 2f) continue
                val hr = max(l.meanH, lineH) / min(l.meanH, lineH)
                val vGap = max(0, max(l.y0 - area.y1, area.y0 - l.y1))
                val overlap = min(l.x1, area.x1) - max(l.x0, area.x0)
                val tol = lineH * 1.5f
                val aligned = overlap > 0 || abs(l.x0 - area.x0) < tol || abs(l.x1 - area.x1) < tol ||
                    abs((l.x0 + l.x1) - (area.x0 + area.x1)) / 2f < tol
                if (hr <= 2.5f && vGap <= max(l.meanH, lineH) * 1.3f && aligned) {
                    used.add(l); area.add(l); pieces.add(intArrayOf(l.x0, l.y0, l.x1, l.y1)); grew = true
                }
            }
        }

        // ── Grow 2: logos / symbols / letters right next to the text (single pass, no chaining) ──
        val low = ByteArray(n) { if (d[it] * pol > t * 0.55f) 1 else 0 }
        val mid = ByteArray(n) { if (d[it] * pol > t * 0.7f) 1 else 0 }
        val textArea = Box(area.x0, area.y0, area.x1, area.y1)
        val reach = (lineH * 1.6f).toInt()
        val sx0 = max(0, area.x0 - (lineH * 6).toInt()); val sx1 = min(sw, area.x1 + 1 + (lineH * 6).toInt())
        val sy0 = max(0, area.y0 - (lineH * 3).toInt()); val sy1 = min(sh, area.y1 + 1 + (lineH * 3).toInt())
        val nearby = ImageOps.components(mid, sw, sx0, sy0, sx1, sy1).filter { c ->
            val ch = c.maxY - c.minY + 1; val cw = c.maxX - c.minX + 1
            c.count >= 4 && ch <= lineH * 3f && cw <= max(lineH * 10f, (area.x1 - area.x0) * 0.6f) &&
                c.count.toFloat() / (ch * cw) <= 0.9f
        }
        for (c in nearby) {
            val (gx, gy) = textArea.gapTo(c)
            // must sit beside the text (same band) or tightly above/below it, in a calm area
            val beside = gx <= reach && gy == 0
            val stacked = gx == 0 && gy <= lineH * 0.8f
            if ((beside || stacked) && clutterOk(mid, sw, c, lineH)) {
                area.add(c); pieces.add(intArrayOf(c.minX, c.minY, c.maxX, c.maxY))
            }
        }

        // ── Grow 3: letters merged with photo detail (e.g. a pole behind a word) ──
        val (ex0, ex1) = extendAlongLine(mid, sw, sh, best)
        val band = (lineH * 0.25f).toInt()
        if (ex0 < best.x0) { pieces.add(intArrayOf(ex0, best.y0 - band, best.x0, best.y1 + band)); area.x0 = min(area.x0, ex0) }
        if (ex1 > best.x1) { pieces.add(intArrayOf(best.x1, best.y0 - band, ex1, best.y1 + band)); area.x1 = max(area.x1, ex1) }

        // ── Mask ──
        val pad = max(2, (lineH / 3).toInt())
        val cx0 = max(0, area.x0 - pad); val cy0 = max(0, area.y0 - pad)
        val cx1 = min(sw, area.x1 + 1 + pad); val cy1 = min(sh, area.y1 + 1 + pad)
        // Solid strokes, plus faint pixels right next to them (soft edges of semi-transparent text).
        // Bounded on purpose: unbounded growth would flood through busy photo texture.
        val seed = ByteArray(n)
        for (r in pieces) {
            for (y in max(0, r[1] - 1)..min(sh - 1, r[3] + 1)) for (x in max(0, r[0] - 1)..min(sw - 1, r[2] + 1)) {
                val i = y * sw + x
                if (mid[i].toInt() != 0) seed[i] = 1
            }
        }
        val near = ImageOps.dilate(seed, sw, sh, 2)
        var small = ByteArray(n)
        for (y in cy0 until cy1) for (x in cx0 until cx1) {
            val i = y * sw + x
            if (seed[i].toInt() != 0 || (low[i].toInt() != 0 && near[i].toInt() != 0)) small[i] = 1
        }
        small = ImageOps.dilate(small, sw, sh, 1)
        ImageOps.fillHoles(small, sw, cx0, cy0, cx1, cy1, maxHole = (lineH * lineH * 1.5f).toInt())
        small = ImageOps.dilate(small, sw, sh, max(2, (lineH / 5).roundToInt()))

        // Scale to full resolution (+ a little extra so soft edges and shadows go too).
        val inv = 1f / s
        val fx0 = max(0, ((cx0 - 6) * inv).toInt()); val fy0 = max(0, ((cy0 - 6) * inv).toInt())
        val fx1 = min(w, ceil((cx1 + 6) * inv).toInt()); val fy1 = min(h, ceil((cy1 + 6) * inv).toInt())
        var full = ByteArray(w * h)
        for (y in fy0 until fy1) {
            val sy = min(sh - 1, (y * s).toInt())
            for (x in fx0 until fx1) full[y * w + x] = small[sy * sw + min(sw - 1, (x * s).toInt())]
        }
        full = ImageOps.dilate(full, w, h, max(1, ceil(inv).toInt() + 1))

        var l = w; var tp = h; var rt = -1; var bt = -1
        for (y in max(0, fy0 - 8) until min(h, fy1 + 8)) for (x in max(0, fx0 - 8) until min(w, fx1 + 8)) {
            if (full[y * w + x].toInt() != 0) {
                if (x < l) l = x; if (x > rt) rt = x
                if (y < tp) tp = y; if (y > bt) bt = y
            }
        }
        if (rt < 0) return null
        return Detection(full, intArrayOf(l, tp, rt, bt), best.zone, best.score)
    }

    /** Rejects blobs sitting in busy texture: the area just around them must be mostly calm. */
    private fun clutterOk(bin: ByteArray, w: Int, c: ImageOps.Component, lineH: Float): Boolean {
        val m = max(2, (lineH * 0.4f).toInt())
        val h = bin.size / w
        val x0 = max(0, c.minX - m); val x1 = min(w - 1, c.maxX + m)
        val y0 = max(0, c.minY - m); val y1 = min(h - 1, c.maxY + m)
        var ring = 0; var ringArea = 0
        for (y in y0..y1) for (x in x0..x1) {
            if (x in c.minX..c.maxX && y in c.minY..c.maxY) continue
            ringArea++; ring += bin[y * w + x]
        }
        return ringArea == 0 || ring.toFloat() / ringArea < 0.08f
    }

    /** Returns the line's new left/right ends after walking over letters merged with photo detail. */
    private fun extendAlongLine(bin: ByteArray, sw: Int, sh: Int, line: Line): Pair<Int, Int> {
        val meanH = line.meanH
        val coreY0 = max(0, (line.meanCy - meanH * 0.3f).toInt()); val coreY1 = min(sh - 1, (line.meanCy + meanH * 0.3f).toInt())
        val maxGap = (meanH * 1.5f).toInt()
        val maxExtend = ((line.x1 - line.x0) * 0.8f).toInt()
        val bandH = max(2, (meanH * 0.6f).toInt())
        val aboveY0 = max(0, line.y0 - 1 - bandH); val aboveY1 = max(0, line.y0 - 2)
        val belowY0 = min(sh - 1, line.y1 + 2); val belowY1 = min(sh - 1, line.y1 + 1 + bandH)
        fun any(x: Int, y0: Int, y1: Int): Boolean { for (y in y0..y1) if (bin[y * sw + x].toInt() != 0) return true; return false }
        fun classify(x: Int): Int = when {   // 1 text-like, 0 empty, -1 occluded by photo detail
            any(x, aboveY0, aboveY1) || any(x, belowY0, belowY1) -> -1
            any(x, coreY0, coreY1) -> 1
            else -> 0
        }
        fun extend(start: Int, step: Int): Int {
            var x = start + step; var lastHit = start; var gap = 0; var occluded = 0
            while (x in 0 until sw && abs(x - start) <= maxExtend && gap <= maxGap && occluded <= maxGap * 3) {
                when (classify(x)) {
                    1 -> { lastHit = x; gap = 0; occluded = 0 }
                    0 -> gap++
                    else -> occluded++
                }
                x += step
            }
            return lastHit
        }
        return extend(line.x0, -1) to extend(line.x1, 1)
    }

    private fun findLines(
        bin: ByteArray, w: Int, h: Int, polarity: Int,
        chroma: FloatArray, chromaBg: FloatArray, d: FloatArray, t: Float,
    ): List<Line> {
        val minDim = min(w, h)
        val minH = max(4, (minDim * 0.008f).toInt())
        val maxH = (minDim * 0.12f).toInt()
        val glyphs = ImageOps.components(bin, w, 0, 0, w, h).mapNotNull { c ->
            val gw = c.maxX - c.minX + 1; val gh = c.maxY - c.minY + 1
            val fill = c.count.toFloat() / (gw * gh)
            if (c.count >= 6 && gh in minH..maxH && gw <= gh * 6 + 4 && fill in 0.08f..0.85f) Glyph(c) else null
        }.sortedBy { it.c.minX }
        if (glyphs.size < 2) return emptyList()

        // Union-find: chain glyphs that look like neighbouring letters on one line.
        val parent = IntArray(glyphs.size) { it }
        fun find(i: Int): Int { var x = i; while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x] }; return x }
        for (i in glyphs.indices) {
            val a = glyphs[i]
            for (j in i + 1 until glyphs.size) {
                val b = glyphs[j]
                val mh = max(a.h, b.h)
                if (b.c.minX - a.c.maxX > mh * 1.2f) break // sorted by minX: nothing further can be closer
                if (max(a.h, b.h) > min(a.h, b.h) * 2.2f) continue
                if (abs(a.cy - b.cy) > mh * 0.6f) continue
                if (b.c.minX - a.c.maxX < -mh) continue
                parent[find(j)] = find(i)
            }
        }
        val groups = HashMap<Int, MutableList<Glyph>>()
        for (i in glyphs.indices) groups.getOrPut(find(i)) { ArrayList() }.add(glyphs[i])

        val lines = ArrayList<Line>()
        for (members in groups.values) {
            if (members.size < 2) continue
            val x0 = members.minOf { it.c.minX }; val x1 = members.maxOf { it.c.maxX }
            val y0 = members.minOf { it.c.minY }; val y1 = members.maxOf { it.c.maxY }
            if (x1 - x0 > w * 0.9f) continue
            val meanH = members.map { it.h }.average().toFloat()
            val meanCy = members.map { it.cy }.average().toFloat()
            val cyStd = sqrt(members.map { (it.cy - meanCy) * (it.cy - meanCy) }.average().toFloat())

            // Clutter: stroke pixels in/around the line's box that are not part of the line.
            val m = (meanH * 0.5f).toInt()
            val bx0 = max(0, x0 - m); val by0 = max(0, y0 - m); val bx1 = min(w - 1, x1 + m); val by1 = min(h - 1, y1 + m)
            var strokes = 0
            var strokeChroma = 0f; var bgChroma = 0f; var contrast = 0f
            for (y in by0..by1) for (x in bx0..bx1) {
                val i = y * w + x
                if (bin[i].toInt() != 0) { strokes++; strokeChroma += chroma[i]; bgChroma += chromaBg[i]; contrast += abs(d[i]) }
            }
            // Real watermark strokes are crisp; faint halos around them are weaker.
            val contrastWeight = if (strokes > 0) sqrt((contrast / strokes / t).coerceIn(0.5f, 4f)) else 1f
            val own = members.sumOf { it.c.count }
            val clutter = max(0, strokes - own).toFloat() / own

            // Watermarks are neutral or wash out the colour under them; photo highlights keep it.
            val colourRatio = if (strokes > 0) (strokeChroma / strokes) / (bgChroma / strokes + 12f) else 0f
            val colourWeight = (1.5f - colourRatio).coerceIn(0.3f, 1f)

            // Watermark text is level. Fit a line through the glyph centres; sloped "lines" are photo edges.
            val mcx = members.map { (it.c.minX + it.c.maxX) / 2f }.average().toFloat()
            var sxy = 0f; var sxx = 0f
            for (gl in members) { val dx = (gl.c.minX + gl.c.maxX) / 2f - mcx; sxy += dx * (gl.cy - meanCy); sxx += dx * dx }
            val slope = if (sxx > 0f) abs(sxy / sxx) else 0f
            val straightWeight = 1f / (1f + 12f * max(0f, slope - 0.04f))

            val (zone, posWeight) = position((x0 + x1) / 2f / w, (y0 + y1) / 2f / h)
            val score = if (members.size < 3) 0f else
                members.size.toFloat().pow(0.7f) * posWeight * colourWeight * contrastWeight * straightWeight / (1f + 3f * cyStd / meanH) / (1f + 2f * clutter)
            val c = if (strokes > 0) contrast / strokes else 0f
            lines.add(Line(polarity, members, x0, y0, x1, y1, meanH, meanCy, score, zone, clutter, colourWeight, c))
        }
        return lines
    }

    /** Weight for where a candidate sits: corners (bottom-right most of all) are typical watermark spots. */
    private fun position(nx: Float, ny: Float): Pair<Zone, Float> {
        val options = listOf(
            Triple(Zone.BOTTOM_RIGHT, hypot(1f - nx, 1f - ny), 1.0f),
            Triple(Zone.BOTTOM_LEFT, hypot(nx, 1f - ny), 0.7f),
            Triple(Zone.TOP_RIGHT, hypot(1f - nx, ny), 0.65f),
            Triple(Zone.TOP_LEFT, hypot(nx, ny), 0.6f),
            Triple(Zone.BOTTOM_CENTER, hypot(0.5f - nx, 1f - ny), 0.6f),
        )
        var bestZone = Zone.OTHER; var bestW = 0.15f
        for ((zone, dist, weight) in options) {
            val wgt = weight * max(0f, 1f - dist * 1.6f)
            if (wgt > bestW) { bestW = wgt; bestZone = zone }
        }
        return bestZone to bestW
    }
}
