package com.watermarkeraser.core

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Exemplar-based inpainting (Criminisi et al.), so removed areas are rebuilt from real texture
 * copied from the surrounding photo instead of being smeared/blurred.
 *
 * To stay fast on a phone the patch search runs on a downscaled copy of the region around the
 * mask; the resulting "copy from where" map is then applied at full resolution, so the filled
 * pixels keep full-resolution detail and grain.
 */
object Inpainter {

    private const val PATCH_R = 4               // 9x9 patches at working resolution
    private const val DIST_W = 4f   // preference for nearby source texture
    private const val MAX_WORK_PIXELS = 260_000f // size budget of the working region

    fun inpaint(px: IntArray, w: Int, h: Int, mask: ByteArray, progress: ((Float) -> Unit)? = null): IntArray {
        val out = px.copyOf()
        var bx0 = w; var by0 = h; var bx1 = -1; var by1 = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) if (mask[row + x].toInt() != 0) {
                if (x < bx0) bx0 = x; if (x > bx1) bx1 = x
                if (y < by0) by0 = y; if (y > by1) by1 = y
            }
        }
        if (bx1 < 0) return out

        // Region of interest: mask bounding box plus surroundings to borrow texture from.
        val margin = max(32, (max(bx1 - bx0, by1 - by0) * 0.6f).toInt())
        val rx0 = max(0, bx0 - margin); val ry0 = max(0, by0 - margin)
        val rx1 = min(w - 1, bx1 + margin); val ry1 = min(h - 1, by1 + margin)
        val rw = rx1 - rx0 + 1; val rh = ry1 - ry0 + 1
        val s = max(1f, sqrt(rw * rh / MAX_WORK_PIXELS))
        val lw = max(1, ceil(rw / s).toInt()); val lh = max(1, ceil(rh / s).toInt())
        val ln = lw * lh

        // Downscale the ROI (area average of known pixels; a block with any masked pixel is unknown).
        val cr = FloatArray(ln); val cg = FloatArray(ln); val cb = FloatArray(ln)
        val lm = ByteArray(ln)
        for (ly in 0 until lh) {
            val fy0 = ry0 + (ly * s).toInt(); val fy1 = min(ry1 + 1, max(fy0 + 1, ry0 + ((ly + 1) * s).toInt()))
            for (lx in 0 until lw) {
                val fx0 = rx0 + (lx * s).toInt(); val fx1 = min(rx1 + 1, max(fx0 + 1, rx0 + ((lx + 1) * s).toInt()))
                var sr = 0; var sg = 0; var sb = 0; var cnt = 0; var masked = false
                for (yy in fy0 until fy1) for (xx in fx0 until fx1) {
                    val i = yy * w + xx
                    if (mask[i].toInt() != 0) { masked = true } else {
                        val p = px[i]; sr += (p shr 16) and 0xff; sg += (p shr 8) and 0xff; sb += p and 0xff; cnt++
                    }
                }
                val li = ly * lw + lx
                if (masked || cnt == 0) lm[li] = 1 else { cr[li] = sr.toFloat() / cnt; cg[li] = sg.toFloat() / cnt; cb[li] = sb.toFloat() / cnt }
            }
        }

        val src = fillLowRes(cr, cg, cb, lm, lw, lh, progress) // source index per filled low-res pixel

        // Apply at full resolution.
        val fillW = bx1 - bx0 + 1; val fillH = by1 - by0 + 1
        val offKey = IntArray(fillW * fillH) { Int.MIN_VALUE }
        for (y in by0..by1) for (x in bx0..bx1) {
            val i = y * w + x
            if (mask[i].toInt() == 0) continue
            val lx = min(lw - 1, ((x - rx0) / s).toInt()); val ly = min(lh - 1, ((y - ry0) / s).toInt())
            val li = ly * lw + lx
            val si = src[li]
            var done = false
            if (si >= 0) {
                val dxl = si % lw - lx; val dyl = si / lw - ly
                val sx = x + (dxl * s).roundToInt(); val sy = y + (dyl * s).roundToInt()
                if (sx in 0 until w && sy in 0 until h && mask[sy * w + sx].toInt() == 0) {
                    out[i] = px[sy * w + sx]
                    offKey[(y - by0) * fillW + (x - bx0)] = (dxl + 2048) * 4096 + (dyl + 2048)
                    done = true
                }
            }
            if (!done) {
                out[i] = (0xff shl 24) or (clamp(cr[li]) shl 16) or (clamp(cg[li]) shl 8) or clamp(cb[li])
            }
        }

        // Soften seams: where neighbouring filled pixels came from different places, or touch the
        // untouched photo, average a 3x3 neighbourhood.
        val smoothed = IntArray(fillW * fillH)
        for (y in by0..by1) for (x in bx0..bx1) smoothed[(y - by0) * fillW + (x - bx0)] = out[y * w + x]
        for (y in by0..by1) for (x in bx0..bx1) {
            val i = y * w + x
            if (mask[i].toInt() == 0) continue
            val k = offKey[(y - by0) * fillW + (x - bx0)]
            var seam = false
            for ((dx, dy) in NEIGHBOURS) {
                val nx = x + dx; val ny = y + dy
                if (nx !in 0 until w || ny !in 0 until h) continue
                if (mask[ny * w + nx].toInt() == 0) { seam = true; break }
                if (nx in bx0..bx1 && ny in by0..by1 && offKey[(ny - by0) * fillW + (nx - bx0)] != k) { seam = true; break }
            }
            if (!seam) continue
            var sr = 0; var sg = 0; var sb = 0; var c = 0
            for (yy in max(0, y - 1)..min(h - 1, y + 1)) for (xx in max(0, x - 1)..min(w - 1, x + 1)) {
                val p = out[yy * w + xx]; sr += (p shr 16) and 0xff; sg += (p shr 8) and 0xff; sb += p and 0xff; c++
            }
            smoothed[(y - by0) * fillW + (x - bx0)] = (0xff shl 24) or ((sr / c) shl 16) or ((sg / c) shl 8) or (sb / c)
        }
        for (y in by0..by1) for (x in bx0..bx1) out[y * w + x] = smoothed[(y - by0) * fillW + (x - bx0)]
        return out
    }

    private val NEIGHBOURS = arrayOf(1 to 0, -1 to 0, 0 to 1, 0 to -1)

    private fun clamp(v: Float) = v.roundToInt().coerceIn(0, 255)

    /**
     * Criminisi fill on the working image. Returns, for each low-res pixel, the index of the pixel it
     * was copied from (-1 when it was never masked or no source exists).
     */
    private fun fillLowRes(
        cr: FloatArray, cg: FloatArray, cb: FloatArray, origMask: ByteArray,
        w: Int, h: Int, progress: ((Float) -> Unit)?,
    ): IntArray {
        val n = w * h
        val r = PATCH_R
        val src = IntArray(n) { -1 }
        val unknown = origMask.copyOf()
        val conf = FloatArray(n) { if (origMask[it].toInt() == 0) 1f else 0f }
        val gray = FloatArray(n) { cr[it] * 0.3f + cg[it] * 0.59f + cb[it] * 0.11f }

        // Valid source patch centres: patch fully inside the image and containing no masked pixel.
        val iw = w + 1
        val integ = IntArray(iw * (h + 1))
        for (y in 0 until h) {
            var rs = 0
            for (x in 0 until w) { rs += origMask[y * w + x]; integ[(y + 1) * iw + x + 1] = integ[y * iw + x + 1] + rs }
        }
        val valid = BooleanArray(n)
        val coarse = ArrayList<Int>()
        for (y in r until h - r) for (x in r until w - r) {
            val sum = integ[(y + r + 1) * iw + x + r + 1] - integ[(y - r) * iw + x + r + 1] -
                integ[(y + r + 1) * iw + x - r] + integ[(y - r) * iw + x - r]
            if (sum == 0) {
                valid[y * w + x] = true
                if ((x and 1) == 0 && (y and 1) == 0) coarse.add(y * w + x)
            }
        }
        if (coarse.isEmpty()) return src
        val coarseArr = coarse.toIntArray()

        var mx0 = w; var my0 = h; var mx1 = -1; var my1 = -1
        var remaining = 0
        for (y in 0 until h) for (x in 0 until w) if (unknown[y * w + x].toInt() != 0) {
            remaining++
            if (x < mx0) mx0 = x; if (x > mx1) mx1 = x
            if (y < my0) my0 = y; if (y > my1) my1 = y
        }
        val total = remaining.toFloat()
        val area = ((2 * r + 1) * (2 * r + 1)).toFloat()

        while (remaining > 0) {
            // 1. Pick the fill-front pixel with the highest priority.
            var bestP = -1; var bestPri = -1f; var bestConf = 0f
            for (y in my0..my1) for (x in mx0..mx1) {
                val i = y * w + x
                if (unknown[i].toInt() == 0) continue
                val onFront = (x > 0 && unknown[i - 1].toInt() == 0) || (x < w - 1 && unknown[i + 1].toInt() == 0) ||
                    (y > 0 && unknown[i - w].toInt() == 0) || (y < h - 1 && unknown[i + w].toInt() == 0)
                if (!onFront) continue
                var c = 0f
                for (yy in max(0, y - r)..min(h - 1, y + r)) for (xx in max(0, x - r)..min(w - 1, x + r)) {
                    if (unknown[yy * w + xx].toInt() == 0) c += conf[yy * w + xx]
                }
                c /= area
                val pri = c * (0.05f + dataTerm(x, y, w, h, unknown, gray))
                if (pri > bestPri) { bestPri = pri; bestP = i; bestConf = c }
            }
            if (bestP < 0) break
            val px = bestP % w; val py = bestP / w

            // 2. Find the best-matching fully known patch (coarse grid, then refine).
            var bestS = -1; var bestD = Float.MAX_VALUE
            for (cand in coarseArr) {
                val d = patchDistance(cand, px, py, w, h, r, unknown, cr, cg, cb, bestD)
                if (d < bestD) { bestD = d; bestS = cand }
            }
            if (bestS < 0) break
            val sx0 = bestS % w; val sy0 = bestS / w
            for (dy in -1..1) for (dx in -1..1) {
                val sx = sx0 + dx; val sy = sy0 + dy
                if (sx < 0 || sy < 0 || sx >= w || sy >= h) continue
                val cand = sy * w + sx
                if (!valid[cand]) continue
                val d = patchDistance(cand, px, py, w, h, r, unknown, cr, cg, cb, bestD)
                if (d < bestD) { bestD = d; bestS = cand }
            }
            val sx = bestS % w; val sy = bestS / w

            // 3. Copy the unknown pixels of the target patch from the source patch.
            for (dy in -r..r) for (dx in -r..r) {
                val tx = px + dx; val ty = py + dy
                if (tx < 0 || ty < 0 || tx >= w || ty >= h) continue
                val ti = ty * w + tx
                if (unknown[ti].toInt() == 0) continue
                val si = (sy + dy) * w + (sx + dx)
                cr[ti] = cr[si]; cg[ti] = cg[si]; cb[ti] = cb[si]; gray[ti] = gray[si]
                src[ti] = si
                conf[ti] = bestConf
                unknown[ti] = 0
                remaining--
            }
            progress?.invoke(1f - remaining / total)
        }
        return src
    }

    /** Sum of squared colour differences over the known pixels of the target patch, plus a small distance bias. */
    private fun patchDistance(
        cand: Int, px: Int, py: Int, w: Int, h: Int, r: Int,
        unknown: ByteArray, cr: FloatArray, cg: FloatArray, cb: FloatArray, limit: Float,
    ): Float {
        val cx = cand % w; val cy = cand / w
        val ddx = (cx - px).toFloat(); val ddy = (cy - py).toFloat()
        var d = (ddx * ddx + ddy * ddy) * DIST_W
        if (d >= limit) return d
        for (dy in -r..r) {
            val ty = py + dy
            if (ty < 0 || ty >= h) continue
            val trow = ty * w; val srow = (cy + dy) * w
            for (dx in -r..r) {
                val tx = px + dx
                if (tx < 0 || tx >= w) continue
                val ti = trow + tx
                if (unknown[ti].toInt() != 0) continue
                val si = srow + cx + dx
                val a = cr[ti] - cr[si]; val b = cg[ti] - cg[si]; val c = cb[ti] - cb[si]
                d += a * a + b * b + c * c
            }
            if (d >= limit) return d
        }
        return d
    }

    /** |isophote · normal| / 255: high where an edge in the photo runs into the hole. */
    private fun dataTerm(x: Int, y: Int, w: Int, h: Int, unknown: ByteArray, gray: FloatArray): Float {
        fun k(xx: Int, yy: Int): Float =
            if (xx < 0 || yy < 0 || xx >= w || yy >= h) 1f else if (unknown[yy * w + xx].toInt() == 0) 1f else 0f
        // Normal of the fill front (gradient of the "known" indicator).
        val nx = (k(x + 1, y - 1) + 2 * k(x + 1, y) + k(x + 1, y + 1)) - (k(x - 1, y - 1) + 2 * k(x - 1, y) + k(x - 1, y + 1))
        val ny = (k(x - 1, y + 1) + 2 * k(x, y + 1) + k(x + 1, y + 1)) - (k(x - 1, y - 1) + 2 * k(x, y - 1) + k(x + 1, y - 1))
        val nl = sqrt(nx * nx + ny * ny)
        if (nl < 1e-3f) return 0f

        // Strongest image gradient among nearby fully-known pixels.
        var gx = 0f; var gy = 0f; var gm = 0f
        for (qy in max(1, y - 2)..min(h - 2, y + 2)) for (qx in max(1, x - 2)..min(w - 2, x + 2)) {
            var ok = true
            loop@ for (yy in qy - 1..qy + 1) for (xx in qx - 1..qx + 1) if (unknown[yy * w + xx].toInt() != 0) { ok = false; break@loop }
            if (!ok) continue
            fun g(xx: Int, yy: Int) = gray[yy * w + xx]
            val ax = (g(qx + 1, qy - 1) + 2 * g(qx + 1, qy) + g(qx + 1, qy + 1)) - (g(qx - 1, qy - 1) + 2 * g(qx - 1, qy) + g(qx - 1, qy + 1))
            val ay = (g(qx - 1, qy + 1) + 2 * g(qx, qy + 1) + g(qx + 1, qy + 1)) - (g(qx - 1, qy - 1) + 2 * g(qx, qy - 1) + g(qx + 1, qy - 1))
            val m = ax * ax + ay * ay
            if (m > gm) { gm = m; gx = ax / 4f; gy = ay / 4f }
        }
        // Isophote is perpendicular to the gradient.
        return abs(-gy * nx / nl + gx * ny / nl) / 255f
    }
}
